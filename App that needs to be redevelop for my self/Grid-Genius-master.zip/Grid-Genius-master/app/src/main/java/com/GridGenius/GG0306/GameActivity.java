package com.GridGenius.GG0306;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Random;

public class GameActivity extends AppCompatActivity implements View.OnTouchListener {
    private TextView disc_0, title_mode, disc_1;
    private ImageView pause_next, pause_home, pause_returns;

    private ImageView dialog_home, dialog_reload;
    private TextView game_status, total_turn, earn_coin, win_type;
    private LinearLayout layout_coin_earn;

    private ImageView flag, pause, home, pause_top, home_top, reload, turn_image;
    private TextView turn_controller;
    private LinearLayout layout_canvas, layout_top_pause_home, layout_bottom_pause_home;
    private LinearLayout layout_blur, layout_win_loss, layout_pause;
    private LayoutInflater inflate;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private boolean isMute, soundMute;
    private Intent intent;
    private String lang;
    private AlertDialog.Builder builder;
    private Random random;
    private Handler handler;
    private GameView gameView;
    private int active_pause_index;
    private int titles[] = new int[]{R.string.mode_title_0, R.string.mode_title_1, R.string.mode_title_2, R.string.mode_title_3};
    private int discs_0[] = new int[]{R.string.disc_0_0, R.string.disc_1_0, R.string.disc_2_0, R.string.disc_3_0};
    private int discs_1[] = new int[]{R.string.disc_0_1, R.string.disc_1_1, R.string.disc_2_1, R.string.disc_3_1};
    private int win_status[] = new int[]{R.string.ai_wins, R.string.draw, R.string.you_win};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        getWindow().setStatusBarColor(getResources().getColor(R.color.trans));
        sharedPreferences = getSharedPreferences("dGenius9G030", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        isMute = sharedPreferences.getBoolean("isMute", false);
        soundMute = sharedPreferences.getBoolean("soundMute", false);
        lang = sharedPreferences.getString("lang", "");

        setContentView(R.layout.activity_game);

        builder = new AlertDialog.Builder(this);
        random = new Random();
        handler = new Handler();

        flag = findViewById(R.id.flag);
        pause = (ImageView) findViewById(R.id.pause);
        home = findViewById(R.id.home);
        pause_top = (ImageView) findViewById(R.id.pause_top);
        home_top = findViewById(R.id.home_top);
        reload = findViewById(R.id.reload);
        turn_image = findViewById(R.id.turn_image);
        turn_controller = findViewById(R.id.turn_controller);
        layout_top_pause_home = findViewById(R.id.layout_top_pause_home);
        layout_bottom_pause_home = findViewById(R.id.layout_bottom_pause_home);

        layout_canvas = (LinearLayout) findViewById(R.id.layout_canvas);
        inflate = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        layout_blur = findViewById(R.id.layout_blur);
        layout_win_loss = findViewById(R.id.layout_win_loss);
        layout_pause = findViewById(R.id.layout_pause);

        disc_0 = findViewById(R.id.disc_0);
        disc_1 = findViewById(R.id.disc_1);
        title_mode = findViewById(R.id.title_mode);
        pause_next = findViewById(R.id.pause_next);
        pause_home = findViewById(R.id.pause_home);
        pause_returns = findViewById(R.id.pause_returns);

        dialog_home = findViewById(R.id.dialog_home);
        dialog_reload = findViewById(R.id.dialog_reload);
        game_status = findViewById(R.id.game_status);
        total_turn = findViewById(R.id.total_turn);
        earn_coin = findViewById(R.id.earn_coin);
        win_type = findViewById(R.id.win_type);
        layout_coin_earn = findViewById(R.id.layout_coin_earn);

        flag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Player.button(soundMute);
            }
        });
        pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                pauseDialog();
            }
        });
        pause_top.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Player.button(soundMute);
                pauseDialog();
            }
        });
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                intent = new Intent(GameActivity.this, LoadActivity.class);
                startActivity(intent);
                finish();
            }
        });
        home_top.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Player.button(soundMute);
                intent = new Intent(GameActivity.this, LoadActivity.class);
                startActivity(intent);
                finish();
            }
        });
        reload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Player.button(soundMute);
                intent = new Intent(GameActivity.this, GameActivity.class);
                startActivity(intent);
                finish();
            }
        });

        layout_top_pause_home.setVisibility(View.GONE);
        layout_bottom_pause_home.setVisibility(View.GONE);
        layout_canvas.post(new Runnable() {
            @Override
            public void run() {
                layout_canvas.removeAllViews();
                Point point = new Point();
                getWindowManager().getDefaultDisplay().getSize(point);
                int screenX = layout_canvas.getWidth();
                int screenY = layout_canvas.getHeight();

                gameView = new GameView(GameActivity.this, screenX, screenY, getResources(), 0);
                gameView.setLayoutParams(new LinearLayout.LayoutParams(screenX, screenY));
                layout_canvas.addView(gameView);

                layout_canvas.setOnTouchListener(GameActivity.this);

                if (gameView.game_mode.equals("gravity")) {
                    layout_top_pause_home.setVisibility(View.GONE);
                    layout_bottom_pause_home.setVisibility(View.VISIBLE);
                } else {
                    layout_top_pause_home.setVisibility(View.VISIBLE);
                    layout_bottom_pause_home.setVisibility(View.GONE);
                }

                update_turn_data();
                reloading_UI();
            }
        });
    }

    private void update_turn_data() {
        turn_controller.setText(gameView.first_player_counter + ":" + gameView.second_player_counter);
        if (gameView.first_player_playing)
            turn_image.setImageResource(gameView.all_zero[gameView.active_zero]);
        else
            turn_image.setImageResource(gameView.all_cross[gameView.active_cross]);
    }

    private void reloading_UI() {
        Runnable r = new Runnable() {
            public void run() {
                if (gameView.isPlaying) {
                    gameView.update();

                    if (gameView.game_over && gameView.game_over_time + gameView.duration < System.currentTimeMillis())
                        game_over();

                    if (!gameView.can_click && gameView.last_click_time + gameView.duration * 2 < System.currentTimeMillis()) {
                        gameView.can_click = true;
                        gameView.let_AI_click();
                    }

                    update_turn_data();
                    reloading_UI();
                }
            }
        };
        handler.postDelayed(r, 100);
    }

    public void pauseDialog() {
        gameView.isPlaying = false;
        layout_blur.setVisibility(View.VISIBLE);
        layout_pause.setVisibility(View.VISIBLE);

        pause_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                active_pause_index++;
                if (active_pause_index > 3)
                    active_pause_index = 0;
                process_pause();
            }
        });

        pause_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                intent = new Intent(GameActivity.this, LoadActivity.class);
                startActivity(intent);
                finish();
            }
        });

        pause_returns.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                gameView.isPlaying = true;
                layout_blur.setVisibility(View.GONE);
                layout_pause.setVisibility(View.GONE);
            }
        });

        process_pause();
    }

    private void process_pause() {
        disc_0.setText(discs_0[active_pause_index]);
        title_mode.setText(titles[active_pause_index]);
        disc_1.setText(discs_1[active_pause_index]);
    }

    private void game_over() {
        gameView.isPlaying = false;
        layout_blur.setVisibility(View.VISIBLE);
        layout_win_loss.setVisibility(View.VISIBLE);

        game_status.setText(win_status[gameView.who_win]);
        win_type.setText(R.string.game_win);
        if (gameView.who_win != gameView.YOU_WIN) {
            layout_coin_earn.setVisibility(View.INVISIBLE);
            win_type.setText(R.string.game_over);
        }

        total_turn.setText(gameView.first_player_counter + " " + getResources().getString(R.string.turns));

        dialog_reload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                intent = new Intent(GameActivity.this, GameActivity.class);
                startActivity(intent);
                finish();
            }
        });
        dialog_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                intent = new Intent(GameActivity.this, LoadActivity.class);
                startActivity(intent);
                finish();
            }
        });


        Gson gson = new Gson();
        Type type = new TypeToken<ArrayList<ArrayList<Integer>>>() {
        }.getType();

        String stored_player_data = sharedPreferences.getString("stored_player_data", "");
        ArrayList<ArrayList<Integer>> player_data = gson.fromJson(stored_player_data, type);

        player_data.get(gameView.player_one).set(1, player_data.get(gameView.player_one).get(1) + gameView.first_player_counter);
        player_data.get(gameView.player_two).set(1, player_data.get(gameView.player_two).get(1) + gameView.first_player_counter);

        int reward = gameView.row * gameView.col;
        int p1 = sharedPreferences.getInt("available_coin", 0);
        if (gameView.who_win == gameView.DRAW) {
            player_data.get(gameView.player_one).set(2, player_data.get(gameView.player_one).get(2) + 1);
            player_data.get(gameView.player_two).set(2, player_data.get(gameView.player_two).get(2) + 1);

            earn_coin.setText("+" + reward / 2);
        } else if (gameView.who_win == gameView.AI_WIN) {
            player_data.get(gameView.player_two).set(2, player_data.get(gameView.player_two).get(2) + 1);
        } else {
            player_data.get(gameView.player_one).set(2, player_data.get(gameView.player_one).get(2) + 1);
            editor.putInt("available_coin", p1 + reward);
            earn_coin.setText("+" + reward);
        }
        editor.apply();

        String json = gson.toJson(player_data);
        editor.putString("stored_player_data", json);
        editor.apply();
    }

    @Override
    protected void onPause() {
        super.onPause();
        gameView.isPlaying = false;
//        if (!isMute)
//            Player.all_screens.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            gameView.isPlaying = true;
            reloading_UI();
        } catch (Exception e) {
        }
//        isMute = sharedPreferences.getBoolean("isMute", false);
//        if (!isMute)
//            Player.all_screens.start();
    }

    @Override
    public void onBackPressed() {
        return;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        int x = (int) event.getX();
        int y = (int) event.getY();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                if (gameView.isPlaying && gameView.can_click && !gameView.gravity_on_animating)
                    processActionDown(x, y);
                break;
            case MotionEvent.ACTION_MOVE:
                if (gameView.isPlaying && gameView.can_click && !gameView.gravity_on_animating)
                    processActionMove(x, y);
                break;
            case MotionEvent.ACTION_UP:
                if (gameView.isPlaying && gameView.can_click && !gameView.gravity_on_animating)
                    processActionUp(x, y);
                break;
        }
        return true;
    }

    private void processActionDown(int x, int y) {

    }

    private void processActionUp(int xp, int yp) {
        Rect clicked = new Rect(xp, yp, xp, yp);

        boolean has_correct_intersection = false;
        for (int i = 0; i < gameView.row; i++) {
            for (int j = 0; j < gameView.col; j++) {
                int x = Math.toIntExact(gameView.game_data.get(i).get(j).get(0));
                int y = Math.toIntExact(gameView.game_data.get(i).get(j).get(1));
                int color = Math.toIntExact(gameView.game_data.get(i).get(j).get(2));
                int index = Math.toIntExact(gameView.game_data.get(i).get(j).get(3));
                long time = gameView.game_data.get(i).get(j).get(4);

                if (index != -1 || time != -1L) // card is taken
                    continue;

//                if (gameView.first_player_playing && color != 0) // card is not belongs to first player
//                    continue;
//
//                if (!gameView.first_player_playing && color == 0) // card is not belongs to second player
//                    continue;

                Rect card = new Rect(x, y, x + gameView.swh, y + gameView.swh);
                if (Rect.intersects(clicked, card)) {
                    if (gameView.first_player_playing) {
                        gameView.game_data.get(i).get(j).set(3, 0L);
                        gameView.first_player_counter++;
                    } else {
                        gameView.game_data.get(i).get(j).set(3, 1L);
                        gameView.second_player_counter++;
                    }

                    gameView.game_data.get(i).get(j).set(4, System.currentTimeMillis());
                    has_correct_intersection = true;
                }
            }
        }

        if (has_correct_intersection) {
            if (gameView.first_player_playing && gameView.game_is_against_AI) {
                gameView.can_click = false;
                gameView.last_click_time = System.currentTimeMillis();
            }

            gameView.first_player_playing = !gameView.first_player_playing;
            gameView.check_game_status();
        }
    }

    private void processActionMove(int x, int y) {

    }
}