package com.GridGenius.GG0306;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

public class ShopActivity extends AppCompatActivity {
    private Uri cameraImageUri;
    private ActivityResultLauncher<Intent> imagePickerLauncher;
    private ActivityResultLauncher<Uri> takePictureLauncher;
    private File photoFile;
    private static final int REQUEST_PERMISSION_CODE = 1000;
    private static final int REQUEST_CODE_READ_IMAGES = 101;

    private Button button_zero_coll_0, button_zero_coll_1, button_zero_coll_2, button_zero_coll_3;
    private Button button_cross_coll_0, button_cross_coll_1, button_cross_coll_2, button_cross_coll_3;
    private Button button_field_0, button_field_1, button_field_2;
    private ImageView custom_bg_image;

    private ImageView back, play;
    private TextView available_coin;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private boolean isMute, soundMute;
    private Intent intent;
    private Random random;
    private String lang;
    private int total_coin;
    private ArrayList<Button> zero_coll = new ArrayList<>();
    private ArrayList<Button> cross_coll = new ArrayList<>();
    private ArrayList<Button> field_coll = new ArrayList<>();
    private ArrayList<Boolean> zero_bought = new ArrayList<>();
    private ArrayList<Boolean> cross_bought = new ArrayList<>();
    private ArrayList<Boolean> field_bought = new ArrayList<>();
    private int active_zero, active_cross, active_field, required_coin = 200;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        getWindow().setStatusBarColor(getResources().getColor(R.color.trans));
        sharedPreferences = getSharedPreferences("dGenius9G030", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        isMute = sharedPreferences.getBoolean("isMute", false);
        soundMute = sharedPreferences.getBoolean("soundMute", false);
        lang = sharedPreferences.getString("lang", "");
        total_coin = sharedPreferences.getInt("available_coin", 0);
        active_zero = sharedPreferences.getInt("active_zero", 0);
        active_cross = sharedPreferences.getInt("active_cross", 0);
        active_field = sharedPreferences.getInt("active_field", 0);

        setContentView(R.layout.activity_shop);

        button_zero_coll_0 = findViewById(R.id.button_zero_coll_0);
        button_zero_coll_1 = findViewById(R.id.button_zero_coll_1);
        button_zero_coll_2 = findViewById(R.id.button_zero_coll_2);
        button_zero_coll_3 = findViewById(R.id.button_zero_coll_3);
        button_cross_coll_0 = findViewById(R.id.button_cross_coll_0);
        button_cross_coll_1 = findViewById(R.id.button_cross_coll_1);
        button_cross_coll_2 = findViewById(R.id.button_cross_coll_2);
        button_cross_coll_3 = findViewById(R.id.button_cross_coll_3);
        button_field_0 = findViewById(R.id.button_field_0);
        button_field_1 = findViewById(R.id.button_field_1);
        button_field_2 = findViewById(R.id.button_field_2);
        back = findViewById(R.id.back);
        available_coin = findViewById(R.id.available_coin);
        play = findViewById(R.id.play);
        custom_bg_image = findViewById(R.id.custom_bg_image);

        zero_coll.add(button_zero_coll_0);
        zero_coll.add(button_zero_coll_1);
        zero_coll.add(button_zero_coll_2);
        zero_coll.add(button_zero_coll_3);
        cross_coll.add(button_cross_coll_0);
        cross_coll.add(button_cross_coll_1);
        cross_coll.add(button_cross_coll_2);
        cross_coll.add(button_cross_coll_3);
        field_coll.add(button_field_0);
        field_coll.add(button_field_1);
        field_coll.add(button_field_2);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Player.button(soundMute);

                finish();
            }
        });

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                intent = new Intent(ShopActivity.this, GameActivity.class);
                startActivity(intent);
            }
        });

        image_choose_station();
        arrange_button();
    }

    private void arrange_button() {
        zero_bought = new ArrayList<>();
        cross_bought = new ArrayList<>();
        field_bought = new ArrayList<>();

        available_coin.setText("" + total_coin);

        zero_bought.add(true);
        cross_bought.add(true);
        field_bought.add(true);
        for (int i = 1; i < 4; i++) {
            zero_bought.add(sharedPreferences.getBoolean("zero_bought_" + i, false));
            cross_bought.add(sharedPreferences.getBoolean("cross_bought_" + i, false));
        }
        field_bought.add(sharedPreferences.getBoolean("field_bought", false));
        File directory = new File(getFilesDir(), "saved_images");
        File file = new File(directory, "player_image.jpg");
        if (file.exists()) {
            custom_bg_image.setImageBitmap(loadImageFromInternalStorage(file.getAbsolutePath()));
            field_bought.add(true);
        } else {
            custom_bg_image.setImageResource(R.drawable.field_2);
            field_bought.add(false);
        }

        for (int i = 0; i < zero_bought.size(); i++) {
            if (i == active_zero) {
                zero_coll.get(i).setBackgroundResource(R.drawable.large_btn_gold);
                zero_coll.get(i).setTextColor(getResources().getColor(R.color.dark_red));
                zero_coll.get(i).setText(getResources().getString(R.string.selected));
            } else {
                zero_coll.get(i).setBackgroundResource(R.drawable.large_btn_gray);
                zero_coll.get(i).setTextColor(getResources().getColor(R.color.dark_gray));

                if (zero_bought.get(i))
                    zero_coll.get(i).setText(getResources().getString(R.string.select));
                else
                    zero_coll.get(i).setText((required_coin + i * 200) + "");

                boolean no_enough_coin = !zero_bought.get(i) && required_coin + i * 200 > total_coin;
                if (!no_enough_coin) {
                    int finalI = i;
                    zero_coll.get(i).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Player.button(soundMute);

                            active_zero = finalI;
                            editor.putInt("active_zero", finalI);
                            if (!zero_bought.get(finalI)) {
                                total_coin -= required_coin + finalI * 200;
                                editor.putInt("available_coin", total_coin);
                                editor.putBoolean("zero_bought_" + finalI, true);
                            }
                            editor.apply();
                            arrange_button();
                        }
                    });
                }
            }
        }

        for (int i = 0; i < cross_bought.size(); i++) {
            if (i == active_cross) {
                cross_coll.get(i).setBackgroundResource(R.drawable.large_btn_gold);
                cross_coll.get(i).setTextColor(getResources().getColor(R.color.dark_red));
                cross_coll.get(i).setText(getResources().getString(R.string.selected));
            } else {
                cross_coll.get(i).setBackgroundResource(R.drawable.large_btn_gray);
                cross_coll.get(i).setTextColor(getResources().getColor(R.color.dark_gray));

                if (cross_bought.get(i))
                    cross_coll.get(i).setText(getResources().getString(R.string.select));
                else
                    cross_coll.get(i).setText((required_coin + i * 200) + "");

                boolean no_enough_coin = !cross_bought.get(i) && required_coin + i * 200 > total_coin;
                if (!no_enough_coin) {
                    int finalI = i;
                    cross_coll.get(i).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Player.button(soundMute);

                            active_cross = finalI;
                            editor.putInt("active_cross", finalI);
                            if (!cross_bought.get(finalI)) {
                                total_coin -= required_coin + finalI * 200;
                                editor.putInt("available_coin", total_coin);
                                editor.putBoolean("cross_bought_" + finalI, true);
                            }
                            editor.apply();
                            arrange_button();
                        }
                    });
                }
            }
        }

        for (int i = 0; i < field_bought.size(); i++) {
            if (i == active_field) {
                field_coll.get(i).setBackgroundResource(R.drawable.large_btn_gold);
                field_coll.get(i).setTextColor(getResources().getColor(R.color.dark_red));
                field_coll.get(i).setText(getResources().getString(R.string.selected));
            } else {
                field_coll.get(i).setBackgroundResource(R.drawable.large_btn_gray);
                field_coll.get(i).setTextColor(getResources().getColor(R.color.dark_gray));

                if (field_bought.get(i))
                    field_coll.get(i).setText(getResources().getString(R.string.select));
                else {
                    field_coll.get(i).setText((required_coin + i * 200) + "");
                    if (i == 2)
                        field_coll.get(i).setText(getResources().getString(R.string.upload));
                }

                boolean no_enough_coin = !field_bought.get(i) && required_coin + i * 200 > total_coin;
                if (!no_enough_coin) {
                    int finalI = i;
                    field_coll.get(i).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Player.button(soundMute);

                            active_field = finalI;
                            editor.putInt("active_field", finalI);
                            if (!field_bought.get(finalI)) {
                                total_coin -= required_coin + finalI * 200;
                                editor.putInt("available_coin", total_coin);
                                editor.putBoolean("field_bought_" + finalI, true);
                            }
                            editor.apply();
                            arrange_button();
                        }
                    });
                }
            }
        }
    }

    private void image_choose_station() {
        imagePickerLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                Uri selectedImageUri = result.getData().getData();
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImageUri);
                    custom_bg_image.setImageBitmap(bitmap);
                    saveImageToInternalStorage(bitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        takePictureLauncher = registerForActivityResult(new ActivityResultContracts.TakePicture(), result -> {
            if (result) {
                try {
                    Bitmap bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(cameraImageUri));
                    custom_bg_image.setImageBitmap(bitmap);
                    saveImageToInternalStorage(bitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        button_field_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Player.button(soundMute);

                showImagePickerDialog();
            }
        });
    }

    private void showImagePickerDialog() {
        String[] options = {"Choose from Gallery", "Take Photo"};
        new AlertDialog.Builder(this).setTitle("Select Option").setItems(options, (dialog, which) -> {
            if (which == 0) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    if (checkPermissions_image()) {
                        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                        imagePickerLauncher.launch(intent);
                    } else {
                        if (ActivityCompat.shouldShowRequestPermissionRationale(ShopActivity.this, Manifest.permission.READ_MEDIA_IMAGES)) {
                            showSettingsRedirectDialog("Gallery");
                        } else {
                            requestPermissions_image();
                        }
                    }
                } else {
                    if (checkPermissions_files()) {
                        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                        imagePickerLauncher.launch(intent);
                    } else {
                        if (ActivityCompat.shouldShowRequestPermissionRationale(ShopActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE)) {
                            showSettingsRedirectDialog("External storage");
                        } else {
                            requestPermissions_files();
                        }
                    }
                }
            } else {
                if (checkPermissions_camera()) {
                    takePhotoFromCamera();
                } else {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(ShopActivity.this, Manifest.permission.CAMERA)) {
                        showSettingsRedirectDialog("Camera");
                    } else {
                        requestPermissions_camera();
                    }
                }
            }
        }).show();
    }

    private boolean checkPermissions_camera() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean checkPermissions_image() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean checkPermissions_files() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermissions_camera() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_PERMISSION_CODE);
    }

    private void requestPermissions_image() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_MEDIA_IMAGES}, REQUEST_PERMISSION_CODE);
    }

    private void requestPermissions_files() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_PERMISSION_CODE);
    }

    private void showSettingsRedirectDialog(String type) {
        new AlertDialog.Builder(this)
                .setTitle("Permission Required")
                .setMessage(type + " permission was denied and won't be requested again. Please enable it manually in Settings.")
                .setPositiveButton("Open Settings", (dialog, which) -> {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    Uri uri = Uri.fromParts("package", getPackageName(), null);
                    intent.setData(uri);
                    startActivity(intent);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void takePhotoFromCamera() {
        try {
            photoFile = createImageFile();
            cameraImageUri = FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".provider", photoFile);
            takePictureLauncher.launch(cameraImageUri);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private File createImageFile() throws IOException {
        String fileName = "profile_image.jpg";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        return File.createTempFile(fileName, ".jpg", storageDir);
    }

    private void saveImageToInternalStorage(Bitmap bitmap) {
        File directory = new File(getFilesDir(), "saved_images");
        if (!directory.exists()) {
            directory.mkdir();
        }

        File file = new File(directory, "player_image.jpg");

        try (FileOutputStream fos = new FileOutputStream(file)) {
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
        } catch (IOException e) {
            e.printStackTrace();
        }

        custom_bg_image.setImageBitmap(loadImageFromInternalStorage(file.getAbsolutePath()));
    }

    private Bitmap loadImageFromInternalStorage(String path) {
        Bitmap bitmap = null;
        try {
            File file = new File(path);
            if (file.exists()) {
                bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return bitmap;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 101) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                takePhotoFromCamera();
            } else {
                Toast.makeText(this, "Camera permission is required.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
//        if (!isMute)
//            Player.all_screens.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
//        isMute = sharedPreferences.getBoolean("isMute", false);
//        if (!isMute)
//            Player.all_screens.start();
    }

    @Override
    public void onBackPressed() {
        return;
    }
}