package com.GridGenius.GG0306;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;
import android.view.View;
import android.os.Handler;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

public class GameView extends View {
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private int screenX, screenY;
    private Resources resources;
    private Random random;
    private Handler handler = new Handler();
    boolean isPlaying = true, game_over, can_click = true, gravity_on_animating;
    long game_over_time, last_click_time;
    int duration = 500;

    private Context context;
    int who_win;
    int AI_WIN = 0, DRAW = 1, YOU_WIN = 2;

    int[] game_colors;
    int active_zero, active_cross, active_field, total_coin;
    String game_mode;
    boolean game_is_against_AI;
    boolean first_player_playing = true;
    int first_player_counter = 0, second_player_counter = 0;
    int[] all_zero = new int[]{R.drawable.zero_coll_0, R.drawable.zero_coll_1, R.drawable.zero_coll_2, R.drawable.zero_coll_3};
    int[] all_cross = new int[]{R.drawable.cross_coll_0, R.drawable.cross_coll_1, R.drawable.cross_coll_2, R.drawable.cross_coll_3};
    int lwh, swh, cx, cy, init_x, init_y, padding, row, col;
    int max_wh, margin, inner_padding, r, c, big_margin;
    ArrayList<Bitmap> small_zero_cross = new ArrayList<>();
    ArrayList<Bitmap> large_zero_cross = new ArrayList<>();
    ArrayList<ArrayList<ArrayList<Long>>> game_data = new ArrayList<>();
    ArrayList<ArrayList<ArrayList<Long>>> advanced_data = new ArrayList<>();
    Bitmap custom_bg;
    int player_one, player_two;


    public GameView(Context mContext, int scX, int scY, Resources res, int level_amount) {
        super(mContext);
        screenX = scX;
        screenY = scY;
        resources = res;
        context = mContext;
        random = new Random();
        cx = screenX / 2;
        cy = screenY / 2;
        padding = screenX / 40;
        screenX -= padding * 2;
        max_wh = screenX / 6;
        margin = padding / 5;
        big_margin = padding * 2;

        sharedPreferences = context.getSharedPreferences("dGenius9G030", context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        total_coin = sharedPreferences.getInt("available_coin", 0);
        active_zero = sharedPreferences.getInt("active_zero", 0);
        active_cross = sharedPreferences.getInt("active_cross", 0);
        active_field = sharedPreferences.getInt("active_field", 0);
        game_mode = sharedPreferences.getString("game_mode", "g33");
        game_is_against_AI = sharedPreferences.getBoolean("game_is_against_AI", true);
        player_one = sharedPreferences.getInt("player_one", 0);
        player_two = sharedPreferences.getInt("player_two", 1);

        set_row_col_WH();

        if (active_field == 0)
            game_colors = new int[]{getResources().getColor(R.color.game_color_0_0), getResources().getColor(R.color.game_color_0_1)};
        else if (active_field == 1)
            game_colors = new int[]{getResources().getColor(R.color.game_color_1_0), getResources().getColor(R.color.game_color_1_1)};
        else {
            game_colors = new int[]{getResources().getColor(R.color.dark_gold), getResources().getColor(R.color.trans)};
            File directory = new File(context.getFilesDir(), "saved_images");
            File file = new File(directory, "player_image.jpg");
            custom_bg = loadImageFromInternalStorage(file.getAbsolutePath());
            custom_bg = Bitmap.createScaledBitmap(custom_bg, swh * col, swh * row, false);
        }

        int z = context.getResources().getIdentifier("zero_coll_" + active_zero, "drawable", context.getPackageName());
        Bitmap bitmap = BitmapFactory.decodeResource(res, z);
        bitmap = Bitmap.createScaledBitmap(bitmap, swh - margin * 2 - inner_padding * 2, swh - margin * 2 - inner_padding * 2, false);
        small_zero_cross.add(bitmap);

        bitmap = Bitmap.createScaledBitmap(bitmap, lwh - margin * 2 - inner_padding * 2 - big_margin * 2, lwh - margin * 2 - inner_padding * 2 - big_margin * 2, false);
        large_zero_cross.add(bitmap);

        int c = context.getResources().getIdentifier("cross_coll_" + active_cross, "drawable", context.getPackageName());
        bitmap = BitmapFactory.decodeResource(res, c);
        bitmap = Bitmap.createScaledBitmap(bitmap, swh - margin * 2 - inner_padding * 2, swh - margin * 2 - inner_padding * 2, false);
        small_zero_cross.add(bitmap);
        bitmap = Bitmap.createScaledBitmap(bitmap, lwh - margin * 2 - inner_padding * 2 - big_margin * 2, lwh - margin * 2 - inner_padding * 2 - big_margin * 2, false);
        large_zero_cross.add(bitmap);


        generate_game_data();
    }

    private void generate_game_data() {
        game_data = new ArrayList<>();
        int counter = 0;
        for (int i = 0; i < row; i++) {
            ArrayList<ArrayList<Long>> row_data = new ArrayList<>();
            for (int j = 0; j < col; j++) {
                ArrayList<Long> col_data = new ArrayList<>();
                long x = init_x + (long) j * swh + margin;
                long y = init_y + (long) i * swh + margin;
                long color = (col % 2 == 1) ? counter % 2 : (counter + i) % 2;
                long index = -1;
                long time = -1;
                col_data.add(x);
                col_data.add(y);
                col_data.add(color);
                col_data.add(index);
                col_data.add(time);
                row_data.add(col_data);
                counter++;
            }
            game_data.add(row_data);
        }

        counter = 0;
        advanced_data = new ArrayList<>();
        for (int i = 0; i < r; i++) {
            ArrayList<ArrayList<Long>> row_data = new ArrayList<>();
            for (int j = 0; j < c; j++) {
                ArrayList<Long> col_data = new ArrayList<>();
                long x = init_x + (long) j * lwh + margin;
                long y = init_y + (long) i * lwh + margin;
                long color = (c % 2 == 1) ? counter % 2 : (counter + i) % 2;
                long index = -1;
                long time = -1;
                col_data.add(x);
                col_data.add(y);
                col_data.add(color);
                col_data.add(index);
                col_data.add(time);
                row_data.add(col_data);
                counter++;
            }
            advanced_data.add(row_data);
        }
    }

    private void set_row_col_WH() {
        if (game_mode.equals("g33")) {
            row = 3;
            col = 3;
        } else if (game_mode.equals("g44")) {
            row = 4;
            col = 4;
        } else if (game_mode.equals("g55")) {
            row = 5;
            col = 5;
        } else if (game_mode.equals("g88")) {
            row = 8;
            col = 8;
        } else if (game_mode.equals("advanced")) {
            row = 9;
            col = 9;
        } else if (game_mode.equals("disappearing")) {
            row = 3;
            col = 3;
        } else {
            row = 10;
            col = 5;
        }

        if (!game_mode.equals("advanced"))
            margin = 0;

        swh = screenX / row;
        if (swh > max_wh)
            swh = max_wh;


        r = row / 3;
        c = col / 3;
        lwh = swh * 3;
        init_x = cx - (swh * col) / 2;
        init_y = cy - (swh * row) / 2;
        inner_padding = swh / 6;
    }

    public void onDraw(Canvas canvas) {
        Paint paint = new Paint();
        paint.setStyle(Paint.Style.FILL);
        canvas.drawColor(Color.TRANSPARENT);

        paint.setColor(getResources().getColor(R.color.light_gold));
        canvas.drawRect(init_x - padding, init_y - padding, init_x + swh * col + padding, init_y + swh * row + padding, paint);

        if (active_field == 2)
            canvas.drawBitmap(custom_bg, init_x, init_y, paint);

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                long x = game_data.get(i).get(j).get(0);
                long y = game_data.get(i).get(j).get(1);
                long color = game_data.get(i).get(j).get(2);
                long index = game_data.get(i).get(j).get(3);
                long time = game_data.get(i).get(j).get(4);

                if (active_field != 2) {
                    paint.setColor(game_colors[(int) color]);
                    canvas.drawRect(x, y, x + swh, y + swh, paint);
                }

                paint.setAlpha(255);
                if (index != -1)
                    canvas.drawBitmap(small_zero_cross.get((int) index), x + inner_padding + margin, y + inner_padding + margin, paint);
            }
        }

        if (game_mode.equals("advanced")) {
            for (int i = 0; i < r; i++) {
                for (int j = 0; j < c; j++) {
                    long x = advanced_data.get(i).get(j).get(0);
                    long y = advanced_data.get(i).get(j).get(1);
                    long color = advanced_data.get(i).get(j).get(2);
                    long index = advanced_data.get(i).get(j).get(3);
                    long time = advanced_data.get(i).get(j).get(4);

                    if (index == -1)
                        continue;

                    paint.setColor(getResources().getColor(R.color.light_gold));
                    paint.setAlpha(150);
                    canvas.drawRect(x, y, x + lwh, y + lwh, paint);

                    paint.setAlpha(255);
                    canvas.drawBitmap(large_zero_cross.get((int) index), x + inner_padding + margin + big_margin, y + inner_padding + margin + big_margin, paint);
                }
            }
        }


        if (game_mode.equals("advanced")) {
            paint.setStrokeWidth(margin);
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(getResources().getColor(R.color.light_gold));
            for (int i = 0; i < r; i++) {
                for (int j = 0; j < c; j++) {
                    long x = advanced_data.get(i).get(j).get(0);
                    long y = advanced_data.get(i).get(j).get(1);

                    canvas.drawRect(x, y, x + lwh, y + lwh, paint);
                }
            }
        }
        if (active_field == 2) {
            paint.setStrokeWidth(margin);
            paint.setStyle(Paint.Style.STROKE);
            paint.setColor(getResources().getColor(R.color.light_gold));
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    long x = game_data.get(i).get(j).get(0);
                    long y = game_data.get(i).get(j).get(1);

                    canvas.drawRect(x, y, x + swh, y + swh, paint);
                }
            }
        }
    }

    public void update() {

        invalidate();
    }

    public void check_game_status() {
        if (game_mode.equals("advanced")) {
            for (int a = 0; a < r; a++) {
                for (int b = 0; b < c; b++) {
                    int start_i = a * 3;
                    int start_j = b * 3;
                    int end_i = a * 3 + 3;
                    int end_j = b * 3 + 3;

                    long index = advanced_data.get(a).get(b).get(3);
                    if (index != -1)
                        continue;

                    check_and_remove_more_than_three_cards(start_i, start_j, end_i, end_j);

                    int winner = get_all_filled_card(row, col, start_i, start_j, end_i, end_j, false);
                    if (winner != -1) {
                        advanced_data.get(a).get(b).set(3, (long) winner);
                        advanced_data.get(a).get(b).set(4, System.currentTimeMillis());

                        for (int i = start_i; i < end_i; i++) {
                            for (int j = start_j; j < end_j; j++) {
                                long time = game_data.get(i).get(j).get(4);

                                if (time != -1)
                                    continue;

                                game_data.get(i).get(j).set(3, (long) winner);
                                game_data.get(i).get(j).set(4, System.currentTimeMillis());
                            }
                        }
                    }
                }
            }

            int winner = get_all_filled_card(r, c, 0, 0, r, c, true);
            confirm_who_win(winner, r, c, advanced_data);
        } else {
            if (game_mode.equals("disappearing"))
                check_and_remove_more_than_three_cards(0, 0, row, col);
            else if (game_mode.equals("gravity")) {
                gravity_on_animating = true;
                start_animate_gravity();
            }

            int winner = get_all_filled_card(row, col, 0, 0, row, col, false);
            confirm_who_win(winner, row, col, game_data);
        }
    }

    private void start_animate_gravity() {
        final Handler handler = new Handler();

        Runnable gravityRunnable = new Runnable() {
            @Override
            public void run() {
                boolean moved = false;

                for (int i = row - 2; i >= 0; i--) {
                    for (int j = 0; j < col; j++) {
                        List<Long> currentCell = game_data.get(i).get(j);
                        List<Long> belowCell = game_data.get(i + 1).get(j);

                        long index = currentCell.get(3);
                        long time = currentCell.get(4);
                        long belowIndex = belowCell.get(3);
                        long belowTime = belowCell.get(4);

                        if ((index != -1 || time != -1) && (belowIndex == -1 && belowTime == -1)) {
                            belowCell.set(3, index);
                            belowCell.set(4, time);
                            currentCell.set(3, -1L);
                            currentCell.set(4, -1L);
                            moved = true;
                        }
                    }
                }

                invalidate();

                if (moved) {
                    handler.postDelayed(this, 100);
                } else
                    gravity_on_animating = false;
            }
        };

        handler.post(gravityRunnable);
    }

    private void check_and_remove_more_than_three_cards(int start_i, int start_j, int end_i, int end_j) {
        ArrayList<ArrayList<Long>> player_one_sorted_time = new ArrayList<>();
        ArrayList<ArrayList<Long>> player_two_sorted_time = new ArrayList<>();
        for (int i = start_i; i < end_i; i++) {
            for (int j = start_j; j < end_j; j++) {
                long ii = game_data.get(i).get(j).get(3);
                long tt = game_data.get(i).get(j).get(4);
                if (tt == -1)
                    continue;

                ArrayList<Long> player_sorted_time = new ArrayList<>();
                player_sorted_time.add((long) i);
                player_sorted_time.add((long) j);
                player_sorted_time.add(tt);

                if (ii == 0)
                    player_one_sorted_time.add(player_sorted_time);
                else
                    player_two_sorted_time.add(player_sorted_time);
            }
        }

        // sort ascending, then remove the older one if in a single 3*3 card have a player more than 3 choices.
        player_one_sorted_time.sort(Comparator.comparingLong(list -> list.get(2)));
        player_two_sorted_time.sort(Comparator.comparingLong(list -> list.get(2)));

        while (player_one_sorted_time.size() > 3) {
            int i = Math.toIntExact(player_one_sorted_time.get(0).get(0));
            int j = Math.toIntExact(player_one_sorted_time.get(0).get(1));
            game_data.get(i).get(j).set(3, -1L);
            game_data.get(i).get(j).set(4, -1L);

            player_one_sorted_time.remove(0);
        }

        while (player_two_sorted_time.size() > 3) {
            int i = Math.toIntExact(player_two_sorted_time.get(0).get(0));
            int j = Math.toIntExact(player_two_sorted_time.get(0).get(1));
            game_data.get(i).get(j).set(3, -1L);
            game_data.get(i).get(j).set(4, -1L);

            player_two_sorted_time.remove(0);
        }
    }

    private void confirm_who_win(int winner, int rr, int cc, ArrayList<ArrayList<ArrayList<Long>>> data) {
        if (winner == 0) {
            who_win = YOU_WIN;
            game_over = true;
            game_over_time = System.currentTimeMillis();
        } else if (winner == 1) {
            who_win = AI_WIN;
            game_over = true;
            game_over_time = System.currentTimeMillis();
        } else {
            boolean all_taken = true;
            for (int i = 0; i < rr; i++) {
                for (int j = 0; j < cc; j++) {
                    long index = data.get(i).get(j).get(3);
                    if (index == -1) {
                        all_taken = false;
                        break;
                    }
                }
            }

            if (all_taken) {
                who_win = DRAW;
                game_over = true;
                game_over_time = System.currentTimeMillis();
            }
        }
    }

    private int get_all_filled_card(int row, int col, int startI, int startJ, int endI, int endJ, boolean is_advanced) {
        ArrayList<ArrayList<ArrayList<Long>>> data = game_data;
        if (is_advanced) data = advanced_data;

        int winner = -1;
        int required = 3;

        ArrayList<ArrayList<ArrayList<Integer>>> success_data = get_field_row_col_diagonal(row, col, startI, startJ, endI, endJ, is_advanced, required);
        ArrayList<ArrayList<Integer>> row_repeated_data = success_data.get(0);
        ArrayList<ArrayList<Integer>> col_repeated_data = success_data.get(1);
        ArrayList<ArrayList<Integer>> diagonal_lr_repeated_data = success_data.get(2);
        ArrayList<ArrayList<Integer>> diagonal_rl_repeated_data = success_data.get(3);

        if (!row_repeated_data.isEmpty()) {
            int r = row_repeated_data.get(0).get(0);
            int s = row_repeated_data.get(0).get(1);
            int e = row_repeated_data.get(0).get(2);
            winner = Math.toIntExact(data.get(r).get(s).get(3));
        } else if (!col_repeated_data.isEmpty()) {
            int c = col_repeated_data.get(0).get(0);
            int s = col_repeated_data.get(0).get(1);
            int e = col_repeated_data.get(0).get(2);
            winner = Math.toIntExact(data.get(s).get(c).get(3));
        } else if (!diagonal_lr_repeated_data.isEmpty()) {
            int s = diagonal_lr_repeated_data.get(0).get(0);
            int e = diagonal_lr_repeated_data.get(0).get(1);
            int r = diagonal_lr_repeated_data.get(0).get(2);
            int c = diagonal_lr_repeated_data.get(0).get(3);
            winner = Math.toIntExact(data.get(r).get(c).get(3));
        } else if (!diagonal_rl_repeated_data.isEmpty()) {
            int s = diagonal_rl_repeated_data.get(0).get(0);
            int e = diagonal_rl_repeated_data.get(0).get(1);
            int r = diagonal_rl_repeated_data.get(0).get(2);
            int c = diagonal_rl_repeated_data.get(0).get(3);
            winner = Math.toIntExact(data.get(r).get(c).get(3));
        }

        return winner;
    }

    public void let_AI_click() {
        ArrayList<ArrayList<Integer>> critical_empty_card = new ArrayList<>();
        int required = 2;
        if (game_mode.equals("advanced")) {
            for (int a = 0; a < r; a++) {
                for (int b = 0; b < c; b++) {
                    int start_i = a * 3;
                    int start_j = b * 3;
                    int end_i = a * 3 + 3;
                    int end_j = b * 3 + 3;

                    long index = advanced_data.get(a).get(b).get(3);
                    if (index != -1)
                        continue;

                    ArrayList<ArrayList<Integer>> tt = get_all_critical_AI_points(r, c, start_i, start_j, end_i, end_j, false, required);
                    for (int i = 0; i < tt.size(); i++) {
                        if (!critical_empty_card.contains(tt.get(i))) {
                            critical_empty_card.add(tt.get(i));
                        }
                    }
                }
            }
        } else {
            critical_empty_card = get_all_critical_AI_points(row, col, 0, 0, row, col, false, required);
        }

        Log.e("", critical_empty_card.toString());
        if (critical_empty_card.isEmpty()) {
            ArrayList<ArrayList<Integer>> all_empty_cards = new ArrayList<>();
            for (int i = 0; i < row; i++) {
                for (int j = 0; j < col; j++) {
                    int x = Math.toIntExact(game_data.get(i).get(j).get(0));
                    int y = Math.toIntExact(game_data.get(i).get(j).get(1));
                    int color = Math.toIntExact(game_data.get(i).get(j).get(2));
                    int index = Math.toIntExact(game_data.get(i).get(j).get(3));
                    long time = game_data.get(i).get(j).get(4);

                    if (index != -1 || time != -1L) // card is taken
                        continue;

//                if (!first_player_playing && color == 0) // card is not belongs to second player
//                    continue;

                    ArrayList<Integer> data = new ArrayList<>();
                    data.add(i);
                    data.add(j);
                    all_empty_cards.add(data);
                }
            }

            if (!all_empty_cards.isEmpty()) {
                second_player_counter++;
                int ii = random.nextInt(all_empty_cards.size());
                game_data.get(all_empty_cards.get(ii).get(0)).get(all_empty_cards.get(ii).get(1)).set(3, 1L);
                game_data.get(all_empty_cards.get(ii).get(0)).get(all_empty_cards.get(ii).get(1)).set(4, System.currentTimeMillis());

                can_click = true;
                first_player_playing = true;
                last_click_time = -1;
                check_game_status();
            }
        } else {
            second_player_counter++;
            int ii = random.nextInt(critical_empty_card.size());
            game_data.get(critical_empty_card.get(ii).get(0)).get(critical_empty_card.get(ii).get(1)).set(3, 1L);
            game_data.get(critical_empty_card.get(ii).get(0)).get(critical_empty_card.get(ii).get(1)).set(4, System.currentTimeMillis());

            can_click = true;
            first_player_playing = true;
            last_click_time = -1;
            check_game_status();
        }
    }

    private ArrayList<ArrayList<Integer>> get_all_critical_AI_points(int row, int col, int startI, int startJ, int endI, int endJ, boolean is_advanced, int required) {
        ArrayList<ArrayList<Integer>> critical_empty_card = new ArrayList<>();
        ArrayList<ArrayList<ArrayList<Integer>>> success_data = get_field_row_col_diagonal(row, col, startI, startJ, endI, endJ, false, required);
        ArrayList<ArrayList<Integer>> row_repeated_data = success_data.get(0);
        ArrayList<ArrayList<Integer>> col_repeated_data = success_data.get(1);
        ArrayList<ArrayList<Integer>> diagonal_lr_repeated_data = success_data.get(2);
        ArrayList<ArrayList<Integer>> diagonal_rl_repeated_data = success_data.get(3);


        if (!row_repeated_data.isEmpty()) {
            int r = row_repeated_data.get(0).get(0);
            int s = row_repeated_data.get(0).get(1);
            int e = row_repeated_data.get(0).get(2);

            ArrayList<Integer> data = new ArrayList<>();
            if (s - 1 >= startI && game_data.get(r).get(s - 1).get(3) == -1L) {
                data.add(r);
                data.add(s - 1);
                critical_empty_card.add(data);
            }
            data = new ArrayList<>();
            if (e + 1 < endJ && game_data.get(r).get(e + 1).get(3) == -1L) {
                data.add(r);
                data.add(e + 1);
                critical_empty_card.add(data);
            }
        }

        if (!col_repeated_data.isEmpty()) {
            int c = col_repeated_data.get(0).get(0);
            int s = col_repeated_data.get(0).get(1);
            int e = col_repeated_data.get(0).get(2);

            ArrayList<Integer> data = new ArrayList<>();
            if (s - 1 >= startI && game_data.get(s - 1).get(c).get(3) == -1L) {
                data.add(s - 1);
                data.add(c);
                critical_empty_card.add(data);
            }
            data = new ArrayList<>();
            if (e + 1 < endI && game_data.get(e + 1).get(c).get(3) == -1L) {
                data.add(e + 1);
                data.add(c);
                critical_empty_card.add(data);
            }
        }

        if (!diagonal_lr_repeated_data.isEmpty()) {
            int sr = diagonal_lr_repeated_data.get(0).get(0);
            int sc = diagonal_lr_repeated_data.get(0).get(1);
            int er = diagonal_lr_repeated_data.get(0).get(2);
            int ec = diagonal_lr_repeated_data.get(0).get(3);

            ArrayList<Integer> data = new ArrayList<>();
            if (sr - 1 >= startI && sc - 1 >= startJ && game_data.get(sr - 1).get(sc - 1).get(3) == -1L) {
                data.add(sr - 1);
                data.add(sc - 1);
                critical_empty_card.add(data);
            }
            data = new ArrayList<>();
            if (er + 1 < endI && ec + 1 < endJ && game_data.get(er + 1).get(ec + 1).get(3) == -1L) {
                data.add(er + 1);
                data.add(ec + 1);
                critical_empty_card.add(data);
            }
        }

        if (!diagonal_rl_repeated_data.isEmpty()) {
            int sr = diagonal_rl_repeated_data.get(0).get(0);
            int sc = diagonal_rl_repeated_data.get(0).get(1);
            int er = diagonal_rl_repeated_data.get(0).get(2);
            int ec = diagonal_rl_repeated_data.get(0).get(3);

            ArrayList<Integer> data = new ArrayList<>();
            if (sr - 1 >= startI && sc + 1 < endJ && game_data.get(sr - 1).get(sc + 1).get(3) == -1L) {
                data.add(sr - 1);
                data.add(sc + 1);
                critical_empty_card.add(data);
            }
            data = new ArrayList<>();
            if (er + 1 < endI && ec - 1 >= startJ && game_data.get(er + 1).get(ec - 1).get(3) == -1L) {
                data.add(er + 1);
                data.add(ec - 1);
                critical_empty_card.add(data);
            }
        }

        return critical_empty_card;
    }

    private Bitmap loadImageFromInternalStorage(String path) {
        Bitmap bitmap = null;
        try {
            File file = new File(path);
            if (file.exists()) {
                bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return bitmap;
    }

    private ArrayList<ArrayList<ArrayList<Integer>>> get_field_row_col_diagonal(int row, int col, int startI, int startJ, int endI, int endJ, boolean is_advanced, int required) {
        ArrayList<ArrayList<ArrayList<Long>>> data = game_data;
        if (is_advanced) data = advanced_data;

        ArrayList<ArrayList<Integer>> row_repeated_data = new ArrayList<>();
        for (int i = startI; i < endI; i++) {
            int count = 1, start = -1;
            for (int j = startJ + 1; j < endJ; j++) {
                long prev = data.get(i).get(j - 1).get(3);
                long curr = data.get(i).get(j).get(3);
                if (prev == -1 || curr != prev) {
                    if (count >= required) {
                        ArrayList<Integer> entry = new ArrayList<>();
                        entry.add(i);
                        entry.add(start);
                        entry.add(j - 1);
                        row_repeated_data.add(entry);
                    }
                    count = 1;
                    start = -1;
                } else {
                    if (count == 1) start = j - 1;
                    count++;
                }
            }
            if (count >= required) {
                ArrayList<Integer> entry = new ArrayList<>();
                entry.add(i);
                entry.add(start);
                entry.add(endJ - 1);
                row_repeated_data.add(entry);
            }
        }

        ArrayList<ArrayList<Integer>> col_repeated_data = new ArrayList<>();
        for (int j = startJ; j < endJ; j++) {
            int count = 1, start = -1;
            for (int i = startI + 1; i < endI; i++) {
                long prev = data.get(i - 1).get(j).get(3);
                long curr = data.get(i).get(j).get(3);
                if (prev == -1 || curr != prev) {
                    if (count >= required) {
                        ArrayList<Integer> entry = new ArrayList<>();
                        entry.add(j);
                        entry.add(start);
                        entry.add(i - 1);
                        col_repeated_data.add(entry);
                    }
                    count = 1;
                    start = -1;
                } else {
                    if (count == 1) start = i - 1;
                    count++;
                }
            }
            if (count >= required) {
                ArrayList<Integer> entry = new ArrayList<>();
                entry.add(j);
                entry.add(start);
                entry.add(endI - 1);
                col_repeated_data.add(entry);
            }
        }

        ArrayList<ArrayList<Integer>> diagonal_lr_repeated_data = new ArrayList<>();
        for (int i = startI; i < endI; i++) {
            for (int j = startJ; j < endJ; j++) {
                int x = i, y = j, count = 1, startX = -1, startY = -1;
                while (x + 1 < endI && y + 1 < endJ) {
                    long curr = data.get(x).get(y).get(3);
                    long next = data.get(x + 1).get(y + 1).get(3);
                    if (next == -1 || curr != next) {
                        if (count >= required) {
                            ArrayList<Integer> entry = new ArrayList<>();
                            entry.add(startX);
                            entry.add(startY);
                            entry.add(x);
                            entry.add(y);
                            diagonal_lr_repeated_data.add(entry);
                        }
                        count = 1;
                        startX = -1;
                        startY = -1;
                    } else {
                        if (count == 1) {
                            startX = x;
                            startY = y;
                        }
                        count++;
                    }
                    x++;
                    y++;
                }
                if (count >= required) {
                    ArrayList<Integer> entry = new ArrayList<>();
                    entry.add(startX);
                    entry.add(startY);
                    entry.add(x);
                    entry.add(y);
                    diagonal_lr_repeated_data.add(entry);
                }
            }
        }

        ArrayList<ArrayList<Integer>> diagonal_rl_repeated_data = new ArrayList<>();
        for (int i = startI; i < endI; i++) {
            for (int j = startJ; j < endJ; j++) {
                int x = i, y = j, count = 1, startX = -1, startY = -1;
                while (x + 1 < endI && y - 1 >= 0) {
                    long curr = data.get(x).get(y).get(3);
                    long next = data.get(x + 1).get(y - 1).get(3);
                    if (next == -1 || curr != next) {
                        if (count >= required) {
                            ArrayList<Integer> entry = new ArrayList<>();
                            entry.add(startX);
                            entry.add(startY);
                            entry.add(x);
                            entry.add(y);
                            diagonal_rl_repeated_data.add(entry);
                        }
                        count = 1;
                        startX = -1;
                        startY = -1;
                    } else {
                        if (count == 1) {
                            startX = x;
                            startY = y;
                        }
                        count++;
                    }
                    x++;
                    y--;
                }
                if (count >= required) {
                    ArrayList<Integer> entry = new ArrayList<>();
                    entry.add(startX);
                    entry.add(startY);
                    entry.add(x);
                    entry.add(y);
                    diagonal_rl_repeated_data.add(entry);
                }
            }
        }

        ArrayList<ArrayList<ArrayList<Integer>>> success_data = new ArrayList<>();
        success_data.add(row_repeated_data);
        success_data.add(col_repeated_data);
        success_data.add(diagonal_lr_repeated_data);
        success_data.add(diagonal_rl_repeated_data);

        return success_data;
    }

}