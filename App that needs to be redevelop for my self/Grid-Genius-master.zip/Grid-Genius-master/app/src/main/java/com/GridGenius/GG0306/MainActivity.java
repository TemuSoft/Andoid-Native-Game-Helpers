package com.GridGenius.GG0306;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity{
    private TextView loading;
    private SharedPreferences sharedPreferences;
    private int angle = 0;
    private Handler handler;
    private int counter = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        getWindow().setStatusBarColor(getResources().getColor(R.color.trans));
        sharedPreferences = getSharedPreferences("dGenius9G030", MODE_PRIVATE);

        setContentView(R.layout.activity_main);
        handler = new Handler();

        loading = (TextView) findViewById(R.id.loading_text);

        Point point = new Point();
        getWindowManager().getDefaultDisplay().getSize(point);

        rotate_loading_UI();
    }

    private void rotate_loading_UI(){
        Runnable r = new Runnable() {
            public void run() {
                counter ++;
                int ttt = counter / 10;

                if (ttt % 4 == 3)
                    loading.setText(getResources().getString(R.string.loading) + "...");
                else if (ttt % 4 == 2)
                    loading.setText(getResources().getString(R.string.loading) + "..");
                else if (ttt % 4 == 1)
                    loading.setText(getResources().getString(R.string.loading) + ".");
                else
                    loading.setText(getResources().getString(R.string.loading) + "");

                if (counter >= 100){
                    Intent intent = new Intent(MainActivity.this, LoadActivity.class);
                    startActivity(intent);
                    finish();
                }else
                    rotate_loading_UI();
            }
        };
        handler.postDelayed(r, 30);

    }

}