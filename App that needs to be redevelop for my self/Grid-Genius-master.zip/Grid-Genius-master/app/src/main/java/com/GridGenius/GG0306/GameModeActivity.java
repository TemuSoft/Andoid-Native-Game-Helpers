package com.GridGenius.GG0306;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class GameModeActivity extends AppCompatActivity {
    private ImageView play, classic_grid, back;
    private TextView game_mode_classic, game_mode_advanced, game_mode_disappearing, game_mode_gravity;
    private LinearLayout layout_classic, layout_advanced, layout_disappearing, layout_gravity;
    private Button against_player, against_ai;
    private Button g33, g44, g55, g88, button_advanced, button_disappearing, button_gravity;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private boolean isMute, soundMute;
    private Intent intent;
    private Random random;
    private String lang;
    private int total_coin, player_one, player_two;
    private ArrayList<Button> buttons = new ArrayList<>();
    private ArrayList<TextView> titles = new ArrayList<>();
    private ArrayList<LinearLayout> layouts = new ArrayList<>();
    private ArrayList<String> game_modes = new ArrayList<>();
    private String game_mode;
    private boolean game_is_against_AI;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        getWindow().setStatusBarColor(getResources().getColor(R.color.trans));
        sharedPreferences = getSharedPreferences("dGenius9G030", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        isMute = sharedPreferences.getBoolean("isMute", false);
        soundMute = sharedPreferences.getBoolean("soundMute", false);
        lang = sharedPreferences.getString("lang", "");
        total_coin = sharedPreferences.getInt("available_coin", 0);
        game_mode = sharedPreferences.getString("game_mode", "g33");
        game_is_against_AI = sharedPreferences.getBoolean("game_is_against_AI", true);
        player_one = sharedPreferences.getInt("player_one", 0);
        player_two = sharedPreferences.getInt("player_two", 1);

        setContentView(R.layout.activity_game_mode);

        g33 = findViewById(R.id.g33);
        g44 = findViewById(R.id.g44);
        g55 = findViewById(R.id.g55);
        g88 = findViewById(R.id.g88);
        back = findViewById(R.id.back);
        button_advanced = findViewById(R.id.button_advanced);
        button_disappearing = findViewById(R.id.button_disappearing);
        button_gravity = findViewById(R.id.button_gravity);
        against_player = findViewById(R.id.against_player);
        against_ai = findViewById(R.id.against_ai);
        play = findViewById(R.id.play);
        classic_grid = findViewById(R.id.classic_grid);

        game_mode_classic = findViewById(R.id.game_mode_classic);
        game_mode_advanced = findViewById(R.id.game_mode_advanced);
        game_mode_disappearing = findViewById(R.id.game_mode_disappearing);
        game_mode_gravity = findViewById(R.id.game_mode_gravity);

        layout_classic = findViewById(R.id.layout_classic);
        layout_advanced = findViewById(R.id.layout_advanced);
        layout_disappearing = findViewById(R.id.layout_disappearing);
        layout_gravity = findViewById(R.id.layout_gravity);

        buttons.add(g33);
        buttons.add(g44);
        buttons.add(g55);
        buttons.add(g88);
        buttons.add(button_advanced);
        buttons.add(button_disappearing);
        buttons.add(button_gravity);

        titles.add(game_mode_classic);
        titles.add(game_mode_classic);
        titles.add(game_mode_classic);
        titles.add(game_mode_classic);
        titles.add(game_mode_advanced);
        titles.add(game_mode_disappearing);
        titles.add(game_mode_gravity);

        layouts.add(layout_classic);
        layouts.add(layout_classic);
        layouts.add(layout_classic);
        layouts.add(layout_classic);
        layouts.add(layout_advanced);
        layouts.add(layout_disappearing);
        layouts.add(layout_gravity);

        game_modes.add("g33");
        game_modes.add("g44");
        game_modes.add("g55");
        game_modes.add("g88");
        game_modes.add("advanced");
        game_modes.add("disappearing");
        game_modes.add("gravity");

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                editor.putBoolean("game_is_against_AI", game_is_against_AI);
                editor.apply();

                intent = new Intent(GameModeActivity.this, GameActivity.class);
                startActivity(intent);
            }
        });

        against_player.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Player.button(soundMute);
                game_is_against_AI = false;
                change_UI();
            }
        });

        against_ai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Player.button(soundMute);
                game_is_against_AI = true;
                change_UI();
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Player.button(soundMute);

                finish();
            }
        });


        process_game_mode();
        change_UI();
    }

    private void change_UI() {
        against_player.setBackgroundResource(R.drawable.large_btn_gray);
        against_player.setTextColor(getResources().getColor(R.color.dark_gray));

        against_ai.setBackgroundResource(R.drawable.large_btn_gray);
        against_ai.setTextColor(getResources().getColor(R.color.dark_gray));

        if (game_is_against_AI) {
            against_ai.setBackgroundResource(R.drawable.large_btn_gold);
            against_ai.setTextColor(getResources().getColor(R.color.dark_red));
        } else {
            against_player.setBackgroundResource(R.drawable.large_btn_gold);
            against_player.setTextColor(getResources().getColor(R.color.dark_red));
        }
    }

    private void process_game_mode() {
        int active_mode = game_modes.indexOf(game_mode);
        if (active_mode < 4) {
            if (active_mode == 0) classic_grid.setImageResource(R.drawable.g33);
            else if (active_mode == 1) classic_grid.setImageResource(R.drawable.g44);
            else if (active_mode == 2) classic_grid.setImageResource(R.drawable.g55);
            else classic_grid.setImageResource(R.drawable.g88);
        } else {
            classic_grid.setImageResource(R.drawable.g33);
        }

        for (int i = 0; i < buttons.size(); i++) {
            if (active_mode == i) {
                buttons.get(i).setBackgroundResource(R.drawable.large_btn_gold);
                buttons.get(i).setTextColor(getResources().getColor(R.color.dark_red));
                titles.get(i).setTextColor(getResources().getColor(R.color.dark_red));
                layouts.get(i).setBackgroundResource(R.color.light_gold);

                if (i > 3) buttons.get(i).setText(getResources().getString(R.string.selected));
            } else {
                buttons.get(i).setBackgroundResource(R.drawable.large_btn_gray);
                buttons.get(i).setTextColor(getResources().getColor(R.color.dark_gray));
                titles.get(i).setTextColor(getResources().getColor(R.color.dark_gray));

                if (active_mode < 3) {
                    if (i > 3)
                        layouts.get(i).setBackgroundResource(R.color.bg_rect);
                } else
                    layouts.get(i).setBackgroundResource(R.color.bg_rect);

                if (i > 3) buttons.get(i).setText(getResources().getString(R.string.select));

                int finalI = i;
                buttons.get(i).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Player.button(soundMute);
                        game_mode = game_modes.get(finalI);
                        editor.putString("game_mode", game_mode);
                        editor.apply();
                        process_game_mode();
                    }
                });
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
//        if (!isMute)
//            Player.all_screens.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
//        isMute = sharedPreferences.getBoolean("isMute", false);
//        if (!isMute)
//            Player.all_screens.start();
    }

    @Override
    public void onBackPressed() {
        return;
    }
}