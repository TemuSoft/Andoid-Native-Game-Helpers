package com.CheckBag.CB1706;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;

public class AddThingsActivity extends AppCompatActivity {
    private ImageView back, add_thing, thing_image, minus, plus;
    private EditText name_of_thing, comments;
    private LinearLayout layout_vertical_categories;
    private Button create, amount;

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private boolean isMute, soundMute;
    private String lang;
    private Intent intent;
    private LayoutInflater inflate;
    private FileAccess fileAccess;
    private String custom_category_str;
    private int thing_amount = 1;
    private String thing_name;
    private int one_edit_journey_id, one_edit_thing_id;
    private DataManager dataManager;
    private String[] casual_cat_names = new String[]{"Clothes", "Electronics", "Cosmetics", "Money", "Bags", "Documents"};
    private ArrayList<String> casual_category = new ArrayList<>();
    private String category_source = DatabaseHelper.CASUAL;
    private int selected_category_index = -1;
    private String selected_category = "";
    private ArrayList<String> custom_category = new ArrayList<>();
    private ArrayList<LinearLayout> layout_cards = new ArrayList<>();
    private ArrayList<String> one_thing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        getWindow().setStatusBarColor(getResources().getColor(R.color.trans));
        sharedPreferences = getSharedPreferences("heckBagB170", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        isMute = sharedPreferences.getBoolean("isMute", false);
        soundMute = sharedPreferences.getBoolean("soundMute", false);
        lang = sharedPreferences.getString("lang", "");
        custom_category_str = sharedPreferences.getString("custom_category", "");
        one_edit_journey_id = sharedPreferences.getInt("one_edit_journey_id", -1);
        one_edit_thing_id = sharedPreferences.getInt("one_edit_thing_id", -1);

        setContentView(R.layout.activity_add_things);
        dataManager = new DataManager(this);

        casual_category.add("cat_0");
        casual_category.add("cat_1");
        casual_category.add("cat_2");
        casual_category.add("cat_3");
        casual_category.add("cat_4");
        casual_category.add("cat_5");
        if (!custom_category_str.isEmpty()) {
            String[] all_cat = custom_category_str.split(Player.category_separator);
            Collections.addAll(custom_category, all_cat);
        }

        inflate = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);

        back = findViewById(R.id.back);
        add_thing = findViewById(R.id.add_thing);
        thing_image = findViewById(R.id.thing_image);
        minus = findViewById(R.id.minus);
        plus = findViewById(R.id.plus);
        name_of_thing = findViewById(R.id.name_of_thing);
        comments = findViewById(R.id.comments);
        layout_vertical_categories = findViewById(R.id.layout_vertical_categories);
        create = findViewById(R.id.create);
        amount = findViewById(R.id.amount);

        fileAccess = new FileAccess(this, thing_image);
        fileAccess.registerLaunchers(this);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                intent = new Intent(AddThingsActivity.this, EditJourneyActivity.class);
                startActivity(intent);
                overridePendingTransition(0, 0);
                finish();
            }
        });

        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                thing_amount -= 1;
                set_thing_amount();
            }
        });

        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                thing_amount += 1;
                set_thing_amount();
            }
        });

        add_thing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                fileAccess.showImagePickerDialog();
            }
        });

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                String name = name_of_thing.getText().toString();
                String comment = comments.getText().toString();

                if (!name.isEmpty()) {
                    if (!selected_category.isEmpty()) {
                        if (one_edit_thing_id == -1) {
                            dataManager.addItemThing(name, comment, thing_name, thing_amount, one_edit_journey_id, selected_category, category_source, DatabaseHelper.PENDING);
                            Toast.makeText(AddThingsActivity.this, "Thing created successfully!", Toast.LENGTH_SHORT).show();
                        } else {
                            ContentValues values = new ContentValues();
                            values.put(DatabaseHelper.JOURNEY_ID, one_edit_journey_id);
                            values.put(DatabaseHelper.TITLE, name);
                            values.put(DatabaseHelper.COMMENT, comment);
                            values.put(DatabaseHelper.FILE_NAME, thing_name);
                            values.put(DatabaseHelper.AMOUNT, thing_amount);
                            values.put(DatabaseHelper.CATEGORY, selected_category);
                            values.put(DatabaseHelper.SOURCE, category_source);
                            values.put(DatabaseHelper.STATUS, DatabaseHelper.PENDING);

                            if (!thing_name.equals(one_thing.get(4)))
                                fileAccess.delete_profile(one_thing.get(4));

                            dataManager.updateItemThing(one_edit_thing_id, values);

                            Toast.makeText(AddThingsActivity.this, "Thing updated successfully!", Toast.LENGTH_SHORT).show();
                        }
                        intent = new Intent(AddThingsActivity.this, EditJourneyActivity.class);
                        startActivity(intent);
                        finish();
                    }else
                        Toast.makeText(AddThingsActivity.this, getString(R.string.category) + " is required!", Toast.LENGTH_SHORT).show();
                } else
                    Toast.makeText(AddThingsActivity.this, getString(R.string.name_of_thing) + " is required!", Toast.LENGTH_SHORT).show();
            }
        });

        if (one_edit_thing_id == -1) {
            thing_name = System.currentTimeMillis() + "";
            fileAccess = new FileAccess(this, thing_image);
            fileAccess.registerLaunchers(this);
            fileAccess.fileName = thing_name;
            create.setText(getResources().getString(R.string.create));
        } else {
            one_thing = dataManager.getThingsItemsByItemID(one_edit_thing_id);
            create.setText(getResources().getString(R.string.update));
            set_input_value(one_thing);
        }

        load_all_category();
    }


    private void set_input_value(ArrayList<String> one_thing) {
        thing_name = one_thing.get(4);
        thing_amount = Integer.parseInt(one_thing.get(5));
        name_of_thing.setText(one_thing.get(2));
        comments.setText(one_thing.get(3));
        selected_category = one_thing.get(6);
        category_source = one_thing.get(7);

        fileAccess = new FileAccess(this, thing_image);
        fileAccess.fileName = thing_name;
        fileAccess.registerLaunchers(this);
        if (!thing_name.isEmpty()) {
            Bitmap bitmap = fileAccess.loadImageFromInternalStorage(thing_name);
            if (bitmap != null)
                thing_image.setImageBitmap(bitmap);
        }
        set_thing_amount();
    }

    private void load_all_category() {
        layout_vertical_categories.removeAllViews();
        layout_cards = new ArrayList<>();

        int counter = 0;
        int s = casual_category.size();
        int col = 3;
        int row = (int) Math.ceil((double) s / col);
        if (s != 0 && row == 0)
            row = 1;
        for (int i = 0; i < row; i++) {
            View horizontal = inflate.inflate(R.layout.horizontal_category, null);
            LinearLayout layout_horizontal = horizontal.findViewById(R.id.layout_horizontal);
            layout_horizontal.removeAllViews();

            for (int j = 0; j < col; j++) {
                if (counter >= s) break;

                View mini_category = inflate.inflate(R.layout.mini_category_card, null);
                LinearLayout layout_card = mini_category.findViewById(R.id.layout_card);
                ImageView category = mini_category.findViewById(R.id.category_img);
                TextView name = mini_category.findViewById(R.id.category_name);

                layout_cards.add(layout_card);

                int f = getResources().getIdentifier(casual_category.get(counter), "drawable", getPackageName());
                category.setImageBitmap(BitmapFactory.decodeResource(getResources(), f));
                name.setText(casual_cat_names[counter]);

                if (category_source.equals(DatabaseHelper.CASUAL) && selected_category_index == -1){
                    if (selected_category.equals(casual_category.get(counter)))
                        selected_category_index = counter;
                }

                layout_horizontal.addView(mini_category);
                counter++;
            }

            layout_vertical_categories.addView(horizontal);
        }

        counter = 0;
        s = custom_category.size();
        col = 3;
        row = (int) Math.ceil((double) s / col);
        if (s != 0 && row == 0)
            row = 1;
        for (int i = 0; i < row; i++) {
            View horizontal = inflate.inflate(R.layout.horizontal_category, null);
            LinearLayout layout_horizontal = horizontal.findViewById(R.id.layout_horizontal);
            layout_horizontal.removeAllViews();

            for (int j = 0; j < col; j++) {
                if (counter >= s) break;

                View mini_category = inflate.inflate(R.layout.mini_category_card, null);
                LinearLayout layout_card = mini_category.findViewById(R.id.layout_card);
                ImageView category = mini_category.findViewById(R.id.category_img);
                TextView name = mini_category.findViewById(R.id.category_name);

                layout_cards.add(layout_card);

                Bitmap bitmap = loadImageFromInternalStorage(custom_category.get(counter));
                if (bitmap != null)
                    category.setImageBitmap(bitmap);

                name.setText(custom_category.get(counter));

                if (category_source.equals(DatabaseHelper.CUSTOM) && selected_category_index == -1){
                    if (selected_category.equals(custom_category.get(counter)))
                        selected_category_index = counter + casual_category.size();
                }

                layout_horizontal.addView(mini_category);
                counter++;
            }

            layout_vertical_categories.addView(horizontal);
        }

        Log.e("", selected_category + " " + category_source + " " + selected_category_index);

        for (int i = 0; i < layout_cards.size(); i++) {
            layout_cards.get(i).setBackgroundResource(R.drawable.bg_btn_inactive);
            if (selected_category_index == i) {
                layout_cards.get(i).setBackgroundResource(R.drawable.bg_btn_yellow);
                if (selected_category_index >= casual_category.size()) {
                    selected_category = custom_category.get(selected_category_index - casual_category.size());
                    category_source = DatabaseHelper.CUSTOM;
                } else {
                    selected_category = casual_category.get(selected_category_index);
                    category_source = DatabaseHelper.CASUAL;
                }
            }

            int finalI = i;
            layout_cards.get(i).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Player.button(soundMute);

                    selected_category_index = finalI;
                    load_all_category();
                }
            });
        }
    }

    public Bitmap loadImageFromInternalStorage(String file_name) {
        File directory = new File(getFilesDir(), "saved_images");
        if (!directory.exists()) {
            directory.mkdir();
        }

        File file = new File(directory, file_name + ".jpg");
        String path = file.getAbsolutePath();
        Bitmap bitmap = null;
        try {
            file = new File(path);
            if (file.exists()) {
                bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return bitmap;
    }

    private void set_thing_amount() {
        if (thing_amount < 1)
            thing_amount = 1;

        amount.setText("" + thing_amount);
    }

    @Override
    protected void onPause() {
        super.onPause();
//        if (!isMute)
//            Player.all_screens.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
//        isMute = sharedPreferences.getBoolean("isMute", false);
//        if (!isMute)
//            Player.all_screens.start();
    }

    @Override
    public void onBackPressed() {
        return;
    }
}