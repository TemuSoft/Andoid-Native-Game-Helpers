package com.CheckBag.CB1706;

import android.app.NotificationManager;
import android.content.Context;

import androidx.work.Data;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import java.util.Calendar;
import java.util.concurrent.TimeUnit;

public class TaskScheduler {

    public static void scheduleTaskNotification(Context context, long taskId, Calendar taskDateTime, int time_notification) {
        long currentTime = System.currentTimeMillis();
        long taskTime = taskDateTime.getTimeInMillis();
        long delay = taskTime - currentTime - TimeUnit.MINUTES.toMillis(time_notification);

        if (delay >= 0) {
            Data inputData = new Data.Builder()
                    .putLong("taskId", taskId)
                    .build();

            OneTimeWorkRequest notificationRequest = new OneTimeWorkRequest.Builder(TaskNotificationWorker.class)
                    .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                    .setInputData(inputData)
                    .build();

            WorkManager.getInstance(context).enqueue(notificationRequest);
        }
    }

    public static void cancelAllNotifications(Context context) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.cancelAll();
        }
    }
}
