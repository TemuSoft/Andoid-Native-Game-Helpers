package com.CheckBag.CB1706;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class Player {

    private static SharedPreferences sharedPreferences;
    private static boolean onVibrating;
    private static Vibrator v;
    private static LayoutInflater inflate;
    private static AlertDialog.Builder builder;
    public static MediaPlayer all_screens, button, music;
    public static String category_separator = ",c-";

    public static void all_screens(Context context, int audio) {
        all_screens = MediaPlayer.create(context, audio);
        all_screens.setLooping(true);
    }

    public static void button(Context context, int audio) {
        button = MediaPlayer.create(context, audio);
        button.setLooping(false);
    }

    public static void music(Context context, int audio) {
        music = MediaPlayer.create(context, audio);
        music.setLooping(false);
    }

    public static void StopAll() {
        try {
            all_screens.pause();
            button.pause();
            music.pause();
        } catch (Exception e) {

        }
    }

    public static void button(boolean soundMute) {
//        if (!soundMute) button.start();
    }

    public static void changeLanguage(Activity activity, SharedPreferences.Editor editor, String lang, boolean reload) {
        Resources resources = activity.getResources();
        Configuration configuration = resources.getConfiguration();
        Locale locale = new Locale(lang);
        configuration.setLocale(locale);
        resources.updateConfiguration(configuration, null);

        editor.putString("lang", lang);
        editor.apply();

        if (reload) {
            Intent intent = new Intent(activity, activity.getClass());
            activity.startActivity(intent);
            activity.finish();
        }
    }

    public static String[] get_string_datetime_from_timestamp(String timestamp) {
        long ts = Long.parseLong(timestamp);
        Date date = new Date(ts);

        SimpleDateFormat date_month = new SimpleDateFormat("dd MMMM", Locale.ENGLISH);
        SimpleDateFormat time = new SimpleDateFormat("hh:mm a", Locale.ENGLISH);
        SimpleDateFormat year = new SimpleDateFormat("yyyy", Locale.ENGLISH);

        return new String[]{date_month.format(date) + " " + year.format(date), time.format(date)};
    }

    public static int[] get_int_datetime_from_timestamp(String timestamp) {
        long ts = Long.parseLong(timestamp);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date(ts));

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        return new int[]{year, month, day, hour, minute};
    }

    public static String get_string_timestamp_from_datetime(String[] data_time) {
        String timestamp = "";
        String dateTimeStr = data_time[0] + " " + data_time[1];
        SimpleDateFormat formatter = new SimpleDateFormat("d MMMM yyyy hh:mm a", Locale.ENGLISH);

        try {
            Date date = formatter.parse(dateTimeStr);
            timestamp = String.valueOf(date.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return timestamp;
    }

    public static String get_ride_time(String des, String dep) {
        long ride_mills = Long.parseLong(des) - Long.parseLong(dep);

        if (ride_mills <= 0) {
            return null;
        } else {
            long hours = ride_mills / (1000 * 60 * 60);
            long minutes = (ride_mills / (1000 * 60)) % 60;

            return String.format("%02d:%02d", hours, minutes);
        }
    }

    public static String[] update_time(TextView hour, TextView minute, TextView type, int hh, int mm, boolean is_am) {
        if (hh < 0)
            hh = 12;
        else if (hh > 12)
            hh = 0;

        if (mm < 0)
            mm = 59;
        else if (mm > 59)
            mm = 0;

        String hhs = (hh < 10) ? "0" + hh : "" + hh;
        String mms = (mm < 10) ? "0" + mm : "" + mm;
        String[] hm = new String[]{hhs, mms};

        String s1 = hm[0] + ":" + hm[1] + " AM";
        String s2 = hm[0] + ":" + hm[1] + " PM";
        String value = is_am ? s1 : s2;

        hour.setText(hm[0]);
        minute.setText(hm[1]);
        type.setText("AM");
        if (!is_am)
            type.setText("PM");

        return new String[]{hhs, mms, value};
    }

    public static String[] get_datetime(String tt) {
        LocalDateTime dateTime = Instant.ofEpochMilli(Long.parseLong(tt))
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime();

        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("HH:mm");
        String formattedDate = dateTime.format(dateFormat);
        String formattedTime = dateTime.format(timeFormat);

        String[] result = { formattedDate, formattedTime };

        return result;
    }
}