package com.CheckBag.CB1706;

import static android.view.View.GONE;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class CreateJourneyActivity extends AppCompatActivity {
    private ImageView back, add_ticket, ticket_image, minus, plus;
    private Button save;
    private Button departure_time, departure_date, destination_time, destination_date, budget;
    private EditText name_of_journey, departure, destination, mode_of_transport;
    private SharedPreferences sharedPreferences;
    private boolean isMute, soundMute;
    private String lang;
    private Intent intent;
    private int budget_amount;
    private String ticket_name;
    private DataManager dataManager;
    private FileAccess fileAccess;
    private Calendar calendar;
    private int[] selected_index = {-1, -1};
    private int date_active_index = 0;
    private int one_edit_journey_id;
    private ArrayList<String> one_journey;
    private boolean is_history_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        getWindow().setStatusBarColor(getResources().getColor(R.color.trans));
        sharedPreferences = getSharedPreferences("heckBagB170", MODE_PRIVATE);
        isMute = sharedPreferences.getBoolean("isMute", false);
        soundMute = sharedPreferences.getBoolean("soundMute", false);
        lang = sharedPreferences.getString("lang", "");
        one_edit_journey_id = sharedPreferences.getInt("one_edit_journey_id", -1);
        is_history_view = sharedPreferences.getBoolean("is_history_view", false);

        setContentView(R.layout.activity_create_journey);
        dataManager = new DataManager(this);
        calendar = Calendar.getInstance();

        minus = findViewById(R.id.minus);
        plus = findViewById(R.id.plus);
        back = findViewById(R.id.back);
        add_ticket = findViewById(R.id.add_ticker);
        ticket_image = findViewById(R.id.ticket_image);
        departure_time = findViewById(R.id.departure_time);
        departure_date = findViewById(R.id.departure_date);
        destination_time = findViewById(R.id.destination_time);
        destination_date = findViewById(R.id.destination_date);
        budget = findViewById(R.id.budget);
        name_of_journey = findViewById(R.id.name_of_journey);
        departure = findViewById(R.id.departure);
        destination = findViewById(R.id.destination);
        mode_of_transport = findViewById(R.id.mode_of_transport);
        save = findViewById(R.id.save);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                intent = new Intent(CreateJourneyActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                budget_amount -= 10;
                set_budget_amount();
            }
        });

        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                budget_amount += 10;
                set_budget_amount();
            }
        });

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                String name = name_of_journey.getText().toString();
                String dep = departure.getText().toString();
                String des = destination.getText().toString();
                String mode = mode_of_transport.getText().toString();

                if (!name.isEmpty()) {
                    if (!dep.isEmpty() && !des.isEmpty()) {
                        if (!mode.isEmpty()) {
                            String[] dep_date_time = new String[]{departure_date.getText().toString(), departure_time.getText().toString()};
                            String[] des_date_time = new String[]{destination_date.getText().toString(), destination_time.getText().toString()};
                            String dep_timestamp = Player.get_string_timestamp_from_datetime(dep_date_time);
                            String des_timestamp = Player.get_string_timestamp_from_datetime(des_date_time);

                            if (Player.get_ride_time(des_timestamp, dep_timestamp) != null) {
                                if (one_edit_journey_id == -1) {
                                    dataManager.addItem(name, dep, dep_timestamp, des, des_timestamp, mode, ticket_name, budget_amount);
                                    Toast.makeText(CreateJourneyActivity.this, "Journey created successfully!", Toast.LENGTH_SHORT).show();
                                } else {
                                    ContentValues values = new ContentValues();
                                    values.put(DatabaseHelper.TITLE, name);
                                    values.put(DatabaseHelper.DEPARTURE, dep);
                                    values.put(DatabaseHelper.DEP_TIMESTAMP, dep_timestamp);
                                    values.put(DatabaseHelper.DESTINATION, des);
                                    values.put(DatabaseHelper.DES_TIMESTAMP, des_timestamp);
                                    values.put(DatabaseHelper.MODE, mode);
                                    values.put(DatabaseHelper.FILE_NAME, ticket_name);
                                    values.put(DatabaseHelper.BUDGET, budget_amount);
//                                        values.put(DatabaseHelper.STATUS, DatabaseHelper.PENDING);

                                    if (!ticket_name.equals(one_journey.get(7)))
                                        fileAccess.delete_profile(one_journey.get(7));

                                    dataManager.updateItem(one_edit_journey_id, values);
                                    Toast.makeText(CreateJourneyActivity.this, "Journey updated successfully!", Toast.LENGTH_SHORT).show();
                                }
                                reset_input_value();

                                intent = new Intent(CreateJourneyActivity.this, MainActivity.class);
                                startActivity(intent);
                                finish();
                            } else
                                Toast.makeText(CreateJourneyActivity.this, getString(R.string.destination) + " is far behind " + getString(R.string.departure) + "!", Toast.LENGTH_SHORT).show();
                        } else
                            Toast.makeText(CreateJourneyActivity.this, getString(R.string.mode_of_transport) + " is required!", Toast.LENGTH_SHORT).show();
                    } else
                        Toast.makeText(CreateJourneyActivity.this, getString(R.string.departure) + " and " + getString(R.string.destination) + " is required!", Toast.LENGTH_SHORT).show();
                } else
                    Toast.makeText(CreateJourneyActivity.this, getString(R.string.name_of_journey) + " is required!", Toast.LENGTH_SHORT).show();
            }
        });

        add_ticket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                fileAccess.showImagePickerDialog();
            }
        });

        departure_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                String[] dep_date_time = new String[]{departure_date.getText().toString(), departure_time.getText().toString()};
                String dep_timestamp = Player.get_string_timestamp_from_datetime(dep_date_time);

                date_active_index = 0;
                calendar.setTimeInMillis(Long.parseLong(dep_timestamp));
                load_departure_date_picker(true);
            }
        });

        destination_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                String[] des_date_time = new String[]{destination_date.getText().toString(), destination_time.getText().toString()};
                String des_timestamp = Player.get_string_timestamp_from_datetime(des_date_time);

                date_active_index = 1;
                calendar.setTimeInMillis(Long.parseLong(des_timestamp));
                load_departure_date_picker(false);
            }
        });

        departure_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                load_departure_time_picker(true, departure_time.getText().toString());
            }
        });

        destination_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                load_departure_time_picker(false, destination_time.getText().toString());
            }
        });

        if (one_edit_journey_id == -1) {
            set_budget_amount();
            reset_input_value();
            ticket_name = System.currentTimeMillis() + "";

            fileAccess = new FileAccess(this, ticket_image);
            fileAccess.registerLaunchers(this);
            fileAccess.fileName = ticket_name;
            save.setText(getResources().getString(R.string.save));
        } else {
            one_journey = dataManager.getJourneyItemsByItemID(one_edit_journey_id);
            save.setText(getResources().getString(R.string.update));
            set_input_value(one_journey);
        }


        if (is_history_view){
            save.setVisibility(GONE);
            minus.setVisibility(GONE);
            plus.setVisibility(GONE);

            departure_time.setEnabled(false);
            departure_date.setEnabled(false);
            destination_time.setEnabled(false);
            destination_date.setEnabled(false);

            name_of_journey.setEnabled(false);
            departure.setEnabled(false);
            destination.setEnabled(false);
            add_ticket.setEnabled(false);
        }
    }

    private void set_input_value(ArrayList<String> one_journey) {
        name_of_journey.setText(one_journey.get(1));
        departure.setText(one_journey.get(2));
        departure_date.setText(Player.get_string_datetime_from_timestamp(one_journey.get(3))[0]);
        departure_time.setText(Player.get_string_datetime_from_timestamp(one_journey.get(3))[1]);
        destination.setText(one_journey.get(4));
        destination_date.setText(Player.get_string_datetime_from_timestamp(one_journey.get(5))[0]);
        destination_time.setText(Player.get_string_datetime_from_timestamp(one_journey.get(5))[1]);
        mode_of_transport.setText(one_journey.get(6));
        ticket_name = one_journey.get(7);

        fileAccess = new FileAccess(this, ticket_image);
        fileAccess.fileName = ticket_name;
        fileAccess.registerLaunchers(this);
        if (!ticket_name.isEmpty()) {
            Bitmap bitmap = fileAccess.loadImageFromInternalStorage(ticket_name);
            if (bitmap != null)
                ticket_image.setImageBitmap(bitmap);
        }
        save.setText(getResources().getString(R.string.update));
        budget_amount = Integer.parseInt(one_journey.get(8));
        set_budget_amount();
    }

    private void load_departure_time_picker(boolean is_departure_time, String time) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = LayoutInflater.from(this);
        View view = inflater.inflate(R.layout.custom_time_picker, null);
        builder.setView(view);

        TextView hour = view.findViewById(R.id.hour);
        TextView minute = view.findViewById(R.id.minute);
        TextView type = view.findViewById(R.id.type);

        ImageView hour_up = view.findViewById(R.id.hour_up);
        ImageView hour_down = view.findViewById(R.id.hour_down);
        ImageView minute_up = view.findViewById(R.id.minute_up);
        ImageView minute_down = view.findViewById(R.id.minute_down);

        builder.setCancelable(false);
        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alertDialog.show();

        String[] parts = time.split(" ");
        String timePart = parts[0];
        String tt = parts[1];

        String[] timeParts = timePart.split(":");
        final int[] hh = {Integer.parseInt(timeParts[0])};
        final int[] mm = {Integer.parseInt(timeParts[1])};
        final boolean[] is_am = {tt.equals("AM")};

        final String[][] hm_value = {Player.update_time(hour, minute, type, hh[0], mm[0], is_am[0])};
        hh[0] = Integer.parseInt(hm_value[0][0]);
        mm[0] = Integer.parseInt(hm_value[0][1]);

        hour_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                hh[0]++;
                hm_value[0] = Player.update_time(hour, minute, type, hh[0], mm[0], is_am[0]);
                hh[0] = Integer.parseInt(hm_value[0][0]);
                mm[0] = Integer.parseInt(hm_value[0][1]);
            }
        });
        hour_down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                hh[0]--;
                hm_value[0] = Player.update_time(hour, minute, type, hh[0], mm[0], is_am[0]);
                hh[0] = Integer.parseInt(hm_value[0][0]);
                mm[0] = Integer.parseInt(hm_value[0][1]);
            }
        });

        minute_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                mm[0]++;
                hm_value[0] = Player.update_time(hour, minute, type, hh[0], mm[0], is_am[0]);
                hh[0] = Integer.parseInt(hm_value[0][0]);
                mm[0] = Integer.parseInt(hm_value[0][1]);
            }
        });
        minute_down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                mm[0]--;
                hm_value[0] = Player.update_time(hour, minute, type, hh[0], mm[0], is_am[0]);
                hh[0] = Integer.parseInt(hm_value[0][0]);
                mm[0] = Integer.parseInt(hm_value[0][1]);
            }
        });

        type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                is_am[0] = !is_am[0];

                hm_value[0] = Player.update_time(hour, minute, type, hh[0], mm[0], is_am[0]);
                hh[0] = Integer.parseInt(hm_value[0][0]);
                mm[0] = Integer.parseInt(hm_value[0][1]);
            }
        });

        hour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                if (is_departure_time)
                    departure_time.setText(hm_value[0][2]);
                else
                    destination_time.setText(hm_value[0][2]);
                alertDialog.dismiss();
            }
        });

        minute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                if (is_departure_time)
                    departure_time.setText(hm_value[0][2]);
                else
                    destination_time.setText(hm_value[0][2]);
                alertDialog.dismiss();
            }
        });
    }

    private void load_departure_date_picker(boolean is_departure_date) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = LayoutInflater.from(this);
        View view = inflater.inflate(R.layout.custom_date_picker, null);
        builder.setView(view);

        TextView txtMonthYear = view.findViewById(R.id.txt_month_year);
        GridLayout calendarGrid = view.findViewById(R.id.calendar_grid);
        ImageView btnPrev = view.findViewById(R.id.btn_prev);
        ImageView btnNext = view.findViewById(R.id.btn_next);

        builder.setCancelable(false);
        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alertDialog.show();
        alertDialog.setCancelable(true);

        btnPrev.setOnClickListener(v -> {
            calendar.add(Calendar.MONTH, -1);
            update_date_dep_des(txtMonthYear, calendarGrid, alertDialog, is_departure_date);
        });

        btnNext.setOnClickListener(v -> {
            calendar.add(Calendar.MONTH, 1);
            update_date_dep_des(txtMonthYear, calendarGrid, alertDialog, is_departure_date);
        });

        update_date_dep_des(txtMonthYear, calendarGrid, alertDialog, is_departure_date);
    }

    private void update_date_dep_des(TextView txtMonthYear, GridLayout calendarGrid, AlertDialog alertDialog, boolean is_departure_date) {
        calendarGrid.removeAllViews();

        SimpleDateFormat sdf = new SimpleDateFormat("MMMM yyyy", Locale.getDefault());
        txtMonthYear.setText(sdf.format(calendar.getTime()));

        Calendar displayCal = (Calendar) calendar.clone();
        displayCal.set(Calendar.DAY_OF_MONTH, 1);

        int currentMonth = displayCal.get(Calendar.MONTH);
        int firstDayOfWeek = displayCal.get(Calendar.DAY_OF_WEEK) - 1;
        displayCal.add(Calendar.DAY_OF_MONTH, -firstDayOfWeek);

        String[] days = {"S", "M", "T", "W", "T", "F", "S"};
        for (String day : days) {
            TextView tv = new TextView(this);
            tv.setText(day);
            calendarGrid.addView(tv);
            tv.setTextColor(getResources().getColor(R.color.title_text));
            tv.setTextSize(21);
            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            tv.setWidth(100);
            tv.setHeight(100);
        }

        int totalCells = 0;
        int counter = 0;
        for (int week = 0; week < 6; week++) {
            int nonCurrentMonthCount = 0;
            View[] rowViews = new View[7];

            for (int dayOfWeek = 0; dayOfWeek < 7; dayOfWeek++) {
                int drawMonth = displayCal.get(Calendar.MONTH);

                TextView dayView = new TextView(this);
                dayView.setText(String.valueOf(displayCal.get(Calendar.DAY_OF_MONTH)));
                dayView.setPadding(20, 20, 20, 20);
                dayView.setTextColor(getResources().getColor(R.color.title_text));
                dayView.setTextSize(21);
                dayView.setWidth(100);
                dayView.setHeight(100);
                dayView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

                if (selected_index[date_active_index] == counter)
                    dayView.setBackgroundResource(R.drawable.bg_btn_yellow);
                else
                    dayView.setBackgroundResource(R.color.trans);

                if (drawMonth != currentMonth) {
                    dayView.setAlpha(0.3f);
                    dayView.setEnabled(false);
                    nonCurrentMonthCount++;
                } else {
                    Calendar selected = (Calendar) displayCal.clone();
                    int finalCounter = counter;
                    dayView.setOnClickListener(v -> {
                        long timestamp = selected.getTimeInMillis();
                        String[] date_time = Player.get_string_datetime_from_timestamp(timestamp + "");

                        if (is_departure_date)
                            departure_date.setText(date_time[0]);
                        else
                            destination_date.setText(date_time[0]);

                        if (selected_index[date_active_index] == finalCounter)
                            alertDialog.dismiss();
                        else {
                            selected_index[date_active_index] = finalCounter;
                            update_date_dep_des(txtMonthYear, calendarGrid, alertDialog, is_departure_date);
                        }

                    });
                }

                rowViews[dayOfWeek] = dayView;
                displayCal.add(Calendar.DAY_OF_MONTH, 1);

                counter++;
            }

            if (nonCurrentMonthCount < 7) {
                for (View view : rowViews) {
                    calendarGrid.addView(view);
                    totalCells++;
                }
            }
        }
    }

    private void reset_input_value() {
        String[] date_time = Player.get_string_datetime_from_timestamp(System.currentTimeMillis() + "");
        departure_date.setText(date_time[0]);
        departure_time.setText(date_time[1]);

        long two_hh_millis = 2 * 60 * 60 * 1000;
        date_time = Player.get_string_datetime_from_timestamp((System.currentTimeMillis() + two_hh_millis) + "");
        destination_date.setText(date_time[0]);
        destination_time.setText(date_time[1]);

        name_of_journey.setText("");
        departure.setText("");
        destination.setText("");
        mode_of_transport.setText("");
        ticket_image.setImageResource(R.drawable.sample_img);

        budget_amount = 0;
        set_budget_amount();
    }

    private void set_budget_amount() {
        if (budget_amount < 0)
            budget_amount = 0;

        budget.setText("$ " + budget_amount);
    }

    @Override
    protected void onPause() {
        super.onPause();
//        if (!isMute)
//            Player.all_screens.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
//        isMute = sharedPreferences.getBoolean("isMute", false);
//        if (!isMute)
//            Player.all_screens.start();
    }

    @Override
    public void onBackPressed() {
        return;
    }
}