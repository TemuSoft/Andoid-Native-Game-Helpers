package com.CheckBag.CB1706;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class RemindersActivity extends AppCompatActivity {
    private ImageView back;
    private LinearLayout layout_vertical;

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private boolean isMute, soundMute;
    private String lang;
    private LayoutInflater inflate;
    private Intent intent;
    private DataManager dataManager;
    private ArrayList<ArrayList<String>> all_reminder = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        getWindow().setStatusBarColor(getResources().getColor(R.color.trans));
        sharedPreferences = getSharedPreferences("heckBagB170", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        isMute = sharedPreferences.getBoolean("isMute", false);
        soundMute = sharedPreferences.getBoolean("soundMute", false);
        lang = sharedPreferences.getString("lang", "");

        setContentView(R.layout.activity_reminders);
        dataManager = new DataManager(this);

        back = findViewById(R.id.back);
        layout_vertical = findViewById(R.id.layout_vertical);
        inflate = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                finish();
            }
        });
    }

    private void load_history() {
        String query = "Select * from " + DatabaseHelper.TABLE_REMINDER;
        all_reminder = dataManager.getAllIReminder(query);
        layout_vertical.removeAllViews();

        for (int i = 0; i < all_reminder.size(); i++) {
            int journey_id = Integer.parseInt(all_reminder.get(i).get(1));
            String timestamp = all_reminder.get(i).get(2);
            String gap = all_reminder.get(i).get(3);

            ArrayList<String> one_journey = dataManager.getJourneyItemsByItemID(journey_id);
            View reminders_card = inflate.inflate(R.layout.reminders_card, null);
            LinearLayout layout_card = reminders_card.findViewById(R.id.layout_card);
            TextView title = reminders_card.findViewById(R.id.title);
            TextView comment = reminders_card.findViewById(R.id.comments);
            TextView destination_date = reminders_card.findViewById(R.id.destination_date);
            TextView destination_time = reminders_card.findViewById(R.id.destination_time);
            ProgressBar progressBar = reminders_card.findViewById(R.id.progressBar);

            String more = Player.get_ride_time(one_journey.get(5), one_journey.get(3)) + " via " + one_journey.get(6);
            title.setText(one_journey.get(1));
            comment.setText(getResources().getString(R.string.journey) + " from " + one_journey.get(2) + " to " + one_journey.get(4) + " for " + more);

            destination_date.setText(Player.get_string_datetime_from_timestamp(one_journey.get(5))[0]);
            destination_time.setText(Player.get_string_datetime_from_timestamp(one_journey.get(5))[1]);

            long dep = Long.parseLong(one_journey.get(3)) / 1000;
            long cur = System.currentTimeMillis() / 1000;
            long des = Long.parseLong(one_journey.get(5)) / 1000;

            int main = (int) (des - dep);
            int pro = Math.toIntExact(des - cur);
            int percent = pro * 100 / main;
            if (percent < 0)
                percent = 0;
            else if (percent > 100)
                percent = 100;

            progressBar.setProgress(100 - percent);

            layout_vertical.addView(reminders_card);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
//        if (!isMute)
//            Player.all_screens.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();

        load_history();
//        isMute = sharedPreferences.getBoolean("isMute", false);
//        if (!isMute)
//            Player.all_screens.start();
    }

    @Override
    public void onBackPressed() {
        return;
    }

}