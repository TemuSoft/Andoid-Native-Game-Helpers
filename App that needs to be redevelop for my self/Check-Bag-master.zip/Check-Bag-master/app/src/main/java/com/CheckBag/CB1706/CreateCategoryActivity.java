package com.CheckBag.CB1706;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class CreateCategoryActivity extends AppCompatActivity {
    private ImageView add, category_img, back;
    private EditText name_of_category;
    private TextView category_name;
    private Button create;

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private boolean isMute, soundMute;
    private String lang;
    private Intent intent;
    private FileAccess fileAccess;
    private String category_value = "", custom_category_str;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        getWindow().setStatusBarColor(getResources().getColor(R.color.trans));
        sharedPreferences = getSharedPreferences("heckBagB170", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        isMute = sharedPreferences.getBoolean("isMute", false);
        soundMute = sharedPreferences.getBoolean("soundMute", false);
        lang = sharedPreferences.getString("lang", "");
        custom_category_str = sharedPreferences.getString("custom_category", "");

        setContentView(R.layout.activity_create_category);

        back = findViewById(R.id.back);
        add = findViewById(R.id.add);
        category_img = findViewById(R.id.category_img);
        category_name = findViewById(R.id.category_name);
        name_of_category = findViewById(R.id.name_of_category);
        create = findViewById(R.id.create);

        name_of_category.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                category_value = name_of_category.getText().toString();
                category_name.setText(category_value);
            }
        });

        fileAccess = new FileAccess(this, category_img);
        fileAccess.registerLaunchers(this);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                intent = new Intent(CreateCategoryActivity.this, CategoriesThingsActivity.class);
                startActivity(intent);
                overridePendingTransition(0, 0);
                finish();
            }
        });

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                if (category_value.isEmpty()) {
                    Toast.makeText(CreateCategoryActivity.this, "Please fill category name please!", Toast.LENGTH_SHORT).show();
                } else {
                    fileAccess.fileName = category_value;
                    fileAccess.showImagePickerDialog();
                    name_of_category.setEnabled(false);
                }
            }
        });

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                if (!name_of_category.getText().toString().isEmpty()) {
                    if (custom_category_str.isEmpty())
                        custom_category_str = category_value;
                    else
                        custom_category_str += Player.category_separator + category_value;

                    editor.putString("custom_category", custom_category_str);
                    editor.apply();

                    intent = new Intent(CreateCategoryActivity.this, CategoriesThingsActivity.class);
                    startActivity(intent);
                    overridePendingTransition(0, 0);
                    finish();
                } else
                    Toast.makeText(CreateCategoryActivity.this, "Please put category name!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
//        if (!isMute)
//            Player.all_screens.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
//        isMute = sharedPreferences.getBoolean("isMute", false);
//        if (!isMute)
//            Player.all_screens.start();
    }

    @Override
    public void onBackPressed() {
        return;
    }
}