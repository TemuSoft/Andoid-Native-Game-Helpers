package com.CheckBag.CB1706;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "database";
    private static final int DATABASE_VERSION = 1;

    // Table name and columns
    public static final String TABLE_THING = "thing";
    public static final String COMMENT = "comment";
    public static final String AMOUNT = "amount";
    public static final String SOURCE = "source";

    public static final String TABLE_REMINDER = "reminder";
    public static final String JOURNEY_ID = "journey_id";
    public static final String REMINDER_TIMESTAMP = "reminder_timestamp";
    public static final String REMINDER_GAP = "reminder_gap";
    public static final String LAST_REMINDER_TIMESTAMP = "last_reminder_timestamp";

    public static final String TABLE_MAIN = "journey";
    public static final String COLUMN_ID = "_id";
    public static final String TITLE = "title";
    public static final String DEPARTURE = "departure";
    public static final String DEP_TIMESTAMP = "dep_timestamp";
    public static final String DESTINATION = "destination";
    public static final String DES_TIMESTAMP = "des_timestamp";
    public static final String MODE = "mode";
    public static final String FILE_NAME = "file_name";
    public static final String BUDGET = "budget";
    public static final String STATUS = "status";
    public static final String CATEGORY = "category";

    public static final String DONE = "done";
    public static final String PENDING = "pending";
    public static final String CHECKED = "checked";
    public static final String RETUNRNED = "returned";
    public static final String CASUAL = "casual";
    public static final String CUSTOM = "custom";


    // Create table SQL statement
    private static final String SQL_CREATE_TABLE_MAIN =
            "CREATE TABLE " + TABLE_MAIN + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    TITLE + " TEXT," +
                    DEPARTURE + " TEXT," +
                    DEP_TIMESTAMP + " TEXT," +
                    DESTINATION + " TEXT," +
                    DES_TIMESTAMP + " TEXT," +
                    MODE + " TEXT," +
                    FILE_NAME + " TEXT," +
                    BUDGET + " INTEGER," +
                    STATUS + " TEXT," +
                    CATEGORY + " TEXT)";

    private static final String SQL_CREATE_TABLE_REMINDER =
            "CREATE TABLE " + TABLE_REMINDER + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    JOURNEY_ID + " INTEGER," +
                    REMINDER_TIMESTAMP + " TEXT," +
                    REMINDER_GAP + " TEXT," +
                    LAST_REMINDER_TIMESTAMP + " TEXT)";


    private static final String SQL_CREATE_TABLE_THING =
            "CREATE TABLE " + TABLE_THING + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    JOURNEY_ID + " INTEGER," +
                    TITLE + " TEXT," +
                    COMMENT + " TEXT," +
                    FILE_NAME + " TEXT," +
                    AMOUNT + " INTEGER," +
                    CATEGORY + " TEXT," +
                    SOURCE + " TEXT," +
                    STATUS + " TEXT)";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_TABLE_MAIN);
        db.execSQL(SQL_CREATE_TABLE_REMINDER);
        db.execSQL(SQL_CREATE_TABLE_THING);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed, this will delete all data
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MAIN);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REMINDER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_THING);

        // Recreate table
        onCreate(db);
    }
}
