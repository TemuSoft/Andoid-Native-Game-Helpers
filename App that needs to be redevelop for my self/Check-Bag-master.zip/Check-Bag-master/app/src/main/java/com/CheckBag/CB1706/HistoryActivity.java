package com.CheckBag.CB1706;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Image;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class HistoryActivity extends AppCompatActivity {
    private ImageView back;
    private LinearLayout layout_vertical;

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private boolean isMute, soundMute;
    private String lang;
    private LayoutInflater inflate;
    private Intent intent;
    private DataManager dataManager;
    private ArrayList<ArrayList<String>> all_history = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        getWindow().setStatusBarColor(getResources().getColor(R.color.trans));
        sharedPreferences = getSharedPreferences("heckBagB170", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        isMute = sharedPreferences.getBoolean("isMute", false);
        soundMute = sharedPreferences.getBoolean("soundMute", false);
        lang = sharedPreferences.getString("lang", "");

        setContentView(R.layout.activity_history);
        dataManager = new DataManager(this);

        back = findViewById(R.id.back);
        layout_vertical = findViewById(R.id.layout_vertical);
        inflate = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                finish();
            }
        });
    }

    private void load_history() {
        String query = "Select * from " + DatabaseHelper.TABLE_MAIN + " where " + DatabaseHelper.STATUS + "='" + DatabaseHelper.DONE + "'";
        all_history = dataManager.getAllItems(query);
        layout_vertical.removeAllViews();

        for (int i = 0; i < all_history.size(); i++) {
            View journeys_card = inflate.inflate(R.layout.history_card, null);
            LinearLayout layout_card = journeys_card.findViewById(R.id.layout_card);
            TextView title = journeys_card.findViewById(R.id.title);
            TextView departure_time = journeys_card.findViewById(R.id.departure_time);
            TextView destination_time = journeys_card.findViewById(R.id.destination_time);
            TextView departure = journeys_card.findViewById(R.id.departure);
            TextView destination = journeys_card.findViewById(R.id.destination);
            TextView mode_of_transport = journeys_card.findViewById(R.id.mode_of_transport);
            TextView budget = journeys_card.findViewById(R.id.budget);
            ImageView detail = journeys_card.findViewById(R.id.detail);
            ImageView delete = journeys_card.findViewById(R.id.delete);

            title.setText(all_history.get(i).get(1));
            departure.setText(all_history.get(i).get(2));
            departure_time.setText(Player.get_string_datetime_from_timestamp(all_history.get(i).get(3))[1]);
            destination.setText(all_history.get(i).get(4));
            destination_time.setText(Player.get_string_datetime_from_timestamp(all_history.get(i).get(5))[1]);
            mode_of_transport.setText(all_history.get(i).get(6));
            budget.setText(all_history.get(i).get(8));

            int journey_id = Integer.parseInt(all_history.get(i).get(0));
            detail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Player.button(soundMute);

                    editor.putBoolean("is_history_view", true);
                    editor.putInt("one_edit_journey_id", journey_id);
                    editor.apply();

                    intent = new Intent(HistoryActivity.this, EditJourneyActivity.class);
                    startActivity(intent);
                }
            });
            delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Player.button(soundMute);

                    // while delete row, delete related image also
                    dataManager.execute("DELETE FROM " + DatabaseHelper.TABLE_MAIN + " WHERE " + DatabaseHelper.COLUMN_ID + "=" + journey_id);
                    dataManager.execute("DELETE FROM " + DatabaseHelper.TABLE_REMINDER + " WHERE " + DatabaseHelper.JOURNEY_ID + "=" + journey_id);
                    dataManager.execute("DELETE FROM " + DatabaseHelper.TABLE_THING + " WHERE " + DatabaseHelper.JOURNEY_ID + "=" + journey_id);

                    intent = new Intent(HistoryActivity.this, HistoryActivity.class);
                    startActivity(intent);
                    finish();
                }
            });

            layout_vertical.addView(journeys_card);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
//        if (!isMute)
//            Player.all_screens.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();

        load_history();
//        isMute = sharedPreferences.getBoolean("isMute", false);
//        if (!isMute)
//            Player.all_screens.start();
    }

    @Override
    public void onBackPressed() {
        return;
    }

}