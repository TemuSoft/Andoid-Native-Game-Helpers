package com.CheckBag.CB1706;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class TaskNotificationWorker extends Worker {

    public static final String CHANNEL_ID = "task_check_notifications";

    public TaskNotificationWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @Override
    public Result doWork() {
        long taskId = getInputData().getLong("taskId", -1);
        if (taskId == -1) {
            return Result.failure();
        }

        DatabaseHelper dbHelper = new DatabaseHelper(getApplicationContext());
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query(DatabaseHelper.TABLE_MAIN, null,
                DatabaseHelper.COLUMN_ID + "=?", new String[]{String.valueOf(taskId)},
                null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            String taskDate = Player.get_datetime(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.DEP_TIMESTAMP)))[0];
            String taskTime = Player.get_datetime(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.DEP_TIMESTAMP)))[1];

            String title = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.TITLE));
            String dept = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.DEP_TIMESTAMP));
            String dest = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.DES_TIMESTAMP));
            String mode = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.MODE));
            String dep = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.DEPARTURE));
            String des = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.DESTINATION));
            String taskTitle = title + " journey, from " + dep + " to " + des + " for " + Player.get_ride_time(dest, dept) + " via " + mode;

            Calendar taskDateTime = getTaskDateTime(taskDate, taskTime);

            sendNotification(taskId, taskTitle, taskDateTime);
            cursor.close();

            String query = "Select * from " + DatabaseHelper.TABLE_REMINDER + " WHERE " + DatabaseHelper.JOURNEY_ID + "=" + taskId;
            cursor = db.rawQuery(query, null);
            if (cursor != null && cursor.moveToFirst()) {
                String reminder_gap = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.REMINDER_GAP));
                long last_reminder_timestamp = Long.parseLong(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.LAST_REMINDER_TIMESTAMP)));
                Log.e("", "update 0 " + Player.get_datetime(last_reminder_timestamp + "")[0] + " " + Player.get_datetime(last_reminder_timestamp + "")[1]);

                int duration = 24 * 60;
                if (reminder_gap.equals("once_a_week"))
                    duration = 7 * 24 * 60;
                else if (reminder_gap.equals("once_a_month"))
                    duration = 30 * 24 * 60;

                last_reminder_timestamp = last_reminder_timestamp + duration * 60 * 1000;
                String new_time = last_reminder_timestamp + "";
                query = "UPDATE " + DatabaseHelper.TABLE_REMINDER + " SET " + DatabaseHelper.LAST_REMINDER_TIMESTAMP + "='" + new_time + "' WHERE " + DatabaseHelper.JOURNEY_ID + "=" + taskId;

                db.execSQL(query);

                String date = Player.get_datetime(last_reminder_timestamp + "")[0];
                String time = Player.get_datetime(last_reminder_timestamp + "")[1];
                save_task_to_notification(taskId, date, time, 0);
            }

        }

        return Result.success();
    }

    private void save_task_to_notification(long id_value, String date, String time, int duration) {
        Calendar taskDateTime = getTaskDateTime(date, time);
        TaskScheduler.scheduleTaskNotification(this.getApplicationContext(), id_value, taskDateTime, duration);
    }


    public static Calendar getTaskDateTime(String date, String time) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault());
        Calendar calendar = Calendar.getInstance();

        try {
            String combined = date + " " + time;
            calendar.setTime(dateFormat.parse(combined));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return calendar;
    }

    private void sendNotification(long taskId, String taskTitle, Calendar taskDateTime) {
        createNotificationChannel();

        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
        String timeText = timeFormat.format(taskDateTime.getTime());

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd:MM:yyyy", Locale.getDefault());
        String dateText = dateFormat.format(taskDateTime.getTime());

        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_ID)
                .setSmallIcon(R.drawable.app_icon)
                .setContentTitle("Task Reminder")
                .setContentText(taskTitle + "\n(departure time " + dateText + " at " + timeText + ")")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(getApplicationContext());
        if (ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        notificationManager.notify((int) taskId, builder.build());
    }


    private void createNotificationChannel() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Task check notifications",
                    NotificationManager.IMPORTANCE_HIGH
            );
            NotificationManager manager = getApplicationContext().getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }
}
