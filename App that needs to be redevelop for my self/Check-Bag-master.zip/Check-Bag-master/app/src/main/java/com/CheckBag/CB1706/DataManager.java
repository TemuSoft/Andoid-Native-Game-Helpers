package com.CheckBag.CB1706;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class DataManager {

    private SQLiteDatabase db;

    public DataManager(Context context) {
        DatabaseHelper dbHelper = new DatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    // Create operation
    public long addItem(String title, String departure, String dep_timestamp, String destination, String des_timestamp, String mode, String ticket_name, int budget) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.TITLE, title);
        values.put(DatabaseHelper.DEPARTURE, departure);
        values.put(DatabaseHelper.DEP_TIMESTAMP, dep_timestamp);
        values.put(DatabaseHelper.DESTINATION, destination);
        values.put(DatabaseHelper.DES_TIMESTAMP, des_timestamp);
        values.put(DatabaseHelper.MODE, mode);
        values.put(DatabaseHelper.FILE_NAME, ticket_name);
        values.put(DatabaseHelper.BUDGET, budget);
        values.put(DatabaseHelper.STATUS, DatabaseHelper.PENDING);
        values.put(DatabaseHelper.CATEGORY, "");

        return db.insert(DatabaseHelper.TABLE_MAIN, null, values);
    }

    // Create operation
    public long addItemReminder(int journey_id, String reminder_timestamp, String reminder_gap, String last_reminder_timestamp) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.JOURNEY_ID, journey_id);
        values.put(DatabaseHelper.REMINDER_TIMESTAMP, reminder_timestamp);
        values.put(DatabaseHelper.REMINDER_GAP, reminder_gap);
        values.put(DatabaseHelper.LAST_REMINDER_TIMESTAMP, last_reminder_timestamp);

        return db.insert(DatabaseHelper.TABLE_REMINDER, null, values);
    }

    // Create operation
    public long addItemThing(String name, String comment, String thing_name, int thing_amount, int journey_id, String category, String source, String status) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.JOURNEY_ID, journey_id);
        values.put(DatabaseHelper.TITLE, name);
        values.put(DatabaseHelper.COMMENT, comment);
        values.put(DatabaseHelper.FILE_NAME, thing_name);
        values.put(DatabaseHelper.AMOUNT, thing_amount);
        values.put(DatabaseHelper.CATEGORY, category);
        values.put(DatabaseHelper.SOURCE, source);
        values.put(DatabaseHelper.STATUS, status);

        return db.insert(DatabaseHelper.TABLE_THING, null, values);
    }

    // Read operation
    public ArrayList<ArrayList<String>> getAllItems(String rawQuery) {
        ArrayList<ArrayList<String>> item_list = new ArrayList<>();

        Cursor cursor = db.rawQuery(rawQuery, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String id = String.valueOf(cursor.getInt(0)); // Index of _id column
                String title = cursor.getString(1); // Index of title column
                String departure = cursor.getString(2); // Index of departure column
                String dep_timestamp = cursor.getString(3); // Index of dep_timestamp column
                String destination = cursor.getString(4); // Index of destination column
                String des_timestamp = cursor.getString(5); // Index of des_timestamp column
                String mode = cursor.getString(6); // Index of mode column
                String ticket_name = cursor.getString(7); // Index of ticket_name column
                String budget = String.valueOf(cursor.getString(8)); // Index of budget column
                String status = cursor.getString(9); // Index of status column
                String category = cursor.getString(10); // Index of category column
                ArrayList<String> one_row = new ArrayList<>();
                one_row.add(id);
                one_row.add(title);
                one_row.add(departure);
                one_row.add(dep_timestamp);
                one_row.add(destination);
                one_row.add(des_timestamp);
                one_row.add(mode);
                one_row.add(ticket_name);
                one_row.add(budget);
                one_row.add(status);
                one_row.add(category);
                item_list.add(one_row);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return item_list;
    }

    // Read operation
    public ArrayList<ArrayList<String>> getAllIReminder(String rawQuery) {
        ArrayList<ArrayList<String>> item_list = new ArrayList<>();

        Cursor cursor = db.rawQuery(rawQuery, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String id = String.valueOf(cursor.getInt(0)); // Index of _id column
                String journey_id = String.valueOf(cursor.getString(1)); // Index of journey id column
                String reminder_timestamp = cursor.getString(2); // Index of reminder_timestamp column
                String reminder_gap = cursor.getString(3); // Index of reminder_gap column
                String last_reminder_timestamp = cursor.getString(4); // Index of last_reminder_timestamp column
                ArrayList<String> one_row = new ArrayList<>();
                one_row.add(id);
                one_row.add(journey_id);
                one_row.add(reminder_timestamp);
                one_row.add(reminder_gap);
                one_row.add(last_reminder_timestamp);
                item_list.add(one_row);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return item_list;
    }

    // Read operation
    public ArrayList<ArrayList<String>> getAllItemsThings(String rawQuery) {
        ArrayList<ArrayList<String>> item_list = new ArrayList<>();

        Cursor cursor = db.rawQuery(rawQuery, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String id = String.valueOf(cursor.getInt(0)); // Index of _id column
                String journey_id = String.valueOf(cursor.getString(1)); // Index of journey_id column
                String title = cursor.getString(2); // Index of title column
                String comment = cursor.getString(3); // Index of comment column
                String file_name = cursor.getString(4); // Index of file_name column
                String amount = String.valueOf(cursor.getString(5)); // Index of amount column
                String category = String.valueOf(cursor.getString(6)); // Index of category column
                String source = String.valueOf(cursor.getString(7)); // Index of source column
                String status = String.valueOf(cursor.getString(8)); // Index of status column
                ArrayList<String> one_row = new ArrayList<>();
                one_row.add(id);
                one_row.add(journey_id);
                one_row.add(title);
                one_row.add(comment);
                one_row.add(file_name);
                one_row.add(amount);
                one_row.add(category);
                one_row.add(source);
                one_row.add(status);
                item_list.add(one_row);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return item_list;
    }

    public int getCountItems(String rawQuery) {
        int count = 0;

        Cursor cursor = db.rawQuery(rawQuery, null);
        if (cursor != null && cursor.moveToFirst()) {
            count = Integer.parseInt(cursor.getString(0));
        }

        return count;
    }

    // Update operation
    public int updateItem(int id, ContentValues values) {
        return db.update(DatabaseHelper.TABLE_MAIN, values, DatabaseHelper.COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }

    // Update operation
    public int updateItemReminder(int id, ContentValues values) {
        return db.update(DatabaseHelper.TABLE_REMINDER, values, DatabaseHelper.COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }

    // Update operation
    public int updateItemThing(int id, ContentValues values) {
        return db.update(DatabaseHelper.TABLE_THING, values, DatabaseHelper.COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }

    public int[] getCountItemsCategory(String rawQuery) {
        int category_count[] = new int[]{0, 0, 0, 0, 0};

        Cursor cursor = db.rawQuery(rawQuery, null);
        if (cursor != null && cursor.moveToFirst()) {
            category_count[0] = Integer.parseInt(cursor.getString(0));
            category_count[1] = Integer.parseInt(cursor.getString(1));
            category_count[2] = Integer.parseInt(cursor.getString(2));
            category_count[3] = Integer.parseInt(cursor.getString(3));
            category_count[4] = Integer.parseInt(cursor.getString(4));
        }

        return category_count;
    }

    public int getAllItemsCount(String query) {
        int count = 0;
        Cursor cursor = db.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            do {
                count = Integer.parseInt(cursor.getString(0));
            } while (cursor.moveToNext());
            cursor.close();
        }

        return count;
    }

    public ArrayList<ArrayList<String>> getAllItemsExactDate(String query) {
        ArrayList<ArrayList<String>> item_list = new ArrayList<>();
        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            do {
                String id = String.valueOf(cursor.getInt(0)); // Index of _id column
                String title = cursor.getString(1); // Index of title column
                String departure = cursor.getString(2); // Index of departure column
                String dep_timestamp = cursor.getString(3); // Index of dep_timestamp column
                String destination = cursor.getString(4); // Index of destination column
                String des_timestamp = cursor.getString(5); // Index of des_timestamp column
                String mode = cursor.getString(6); // Index of mode column
                String ticket_name = cursor.getString(7); // Index of ticket_name column
                String budget = String.valueOf(cursor.getString(8)); // Index of budget column
                String status = cursor.getString(9); // Index of status column
                String category = cursor.getString(10); // Index of category column
                ArrayList<String> one_row = new ArrayList<>();
                one_row.add(id);
                one_row.add(title);
                one_row.add(departure);
                one_row.add(dep_timestamp);
                one_row.add(destination);
                one_row.add(des_timestamp);
                one_row.add(mode);
                one_row.add(ticket_name);
                one_row.add(budget);
                one_row.add(status);
                one_row.add(category);
                item_list.add(one_row);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return item_list;
    }

    // Read operation
    public ArrayList<String> getJourneyItemsByItemID(int itemId) {
        ArrayList<String> one_row = new ArrayList<>();
        String selection = DatabaseHelper.COLUMN_ID + "=?";
        String[] selectionArgs = {String.valueOf(itemId)};
        Cursor cursor = db.query(DatabaseHelper.TABLE_MAIN, null, selection, selectionArgs, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                String id = String.valueOf(cursor.getInt(0)); // Index of _id column
                String title = cursor.getString(1); // Index of title column
                String departure = cursor.getString(2); // Index of departure column
                String dep_timestamp = cursor.getString(3); // Index of dep_timestamp column
                String destination = cursor.getString(4); // Index of destination column
                String des_timestamp = cursor.getString(5); // Index of des_timestamp column
                String mode = cursor.getString(6); // Index of mode column
                String ticket_name = cursor.getString(7); // Index of ticket_name column
                String budget = String.valueOf(cursor.getString(8)); // Index of budget column
                String status = cursor.getString(9); // Index of status column
                String category = cursor.getString(10); // Index of category column
                one_row.add(id);
                one_row.add(title);
                one_row.add(departure);
                one_row.add(dep_timestamp);
                one_row.add(destination);
                one_row.add(des_timestamp);
                one_row.add(mode);
                one_row.add(ticket_name);
                one_row.add(budget);
                one_row.add(status);
                one_row.add(category);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return one_row;
    }

    public ArrayList<String> getReminderItemsByItemID(int itemId) {
        ArrayList<String> one_row = new ArrayList<>();
        String selection = DatabaseHelper.COLUMN_ID + "=?";
        String[] selectionArgs = {String.valueOf(itemId)};
        Cursor cursor = db.query(DatabaseHelper.TABLE_REMINDER, null, selection, selectionArgs, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                String id = String.valueOf(cursor.getInt(0)); // Index of _id column
                String journey_id = cursor.getString(1); // Index of journey_id column
                String reminder_timestamp = cursor.getString(2); // Index of reminder_timestamp column
                String reminder_gap = String.valueOf(cursor.getString(3)); // Index of reminder_gap column
                String last_reminder_timestamp = cursor.getString(4); // Index of last_reminder_timestamp column
                one_row.add(id);
                one_row.add(journey_id);
                one_row.add(reminder_timestamp);
                one_row.add(reminder_gap);
                one_row.add(last_reminder_timestamp);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return one_row;
    }

    // Read operation
    public ArrayList<String> getThingsItemsByItemID(int itemId) {
        ArrayList<String> one_row = new ArrayList<>();
        String selection = DatabaseHelper.COLUMN_ID + "=?";
        String[] selectionArgs = {String.valueOf(itemId)};
        Cursor cursor = db.query(DatabaseHelper.TABLE_THING, null, selection, selectionArgs, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                String id = String.valueOf(cursor.getInt(0)); // Index of _id column
                String journey_id = String.valueOf(cursor.getString(1)); // Index of journey_id column
                String title = cursor.getString(2); // Index of title column
                String comment = cursor.getString(3); // Index of comment column
                String file_name = cursor.getString(4); // Index of file_name column
                String amount = String.valueOf(cursor.getString(5)); // Index of amount column
                String category = String.valueOf(cursor.getString(6)); // Index of category column
                String source = String.valueOf(cursor.getString(7)); // Index of source column
                String status = String.valueOf(cursor.getString(8)); // Index of source column
                one_row.add(id);
                one_row.add(journey_id);
                one_row.add(title);
                one_row.add(comment);
                one_row.add(file_name);
                one_row.add(amount);
                one_row.add(category);
                one_row.add(source);
                one_row.add(status);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return one_row;
    }


    // Update operation
    public void execute(String query) {
        db.execSQL(query);
//        return db.update(DatabaseHelper.TABLE_MAIN, values, DatabaseHelper.COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }

    // Delete operation
    public void deleteItem(String query) {
        db.rawQuery(query, null);
    }

    // Delete operation
    public int deleteAllItem() {
        return db.delete(DatabaseHelper.TABLE_MAIN, null, null);
    }
}
