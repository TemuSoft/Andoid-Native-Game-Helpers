package com.CheckBag.CB1706;

import static android.view.View.GONE;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class EditJourneyActivity extends AppCompatActivity {
    private Button add_reminder, finish_journey, delete_journey, check_mode, return_trip_mode, reminder_time, reminder_date, check_bag;
    private ImageView back, edit_journey, add_category, once_a_day, once_a_week, once_a_month;
    private TextView title, departure_time, destination_time, departure, destination, ride_time;
    private LinearLayout layout_vertical_category;

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private boolean isMute, soundMute;
    private String lang;
    private Intent intent;
    private DataManager dataManager;
    private int one_edit_journey_id;
    private boolean is_history_view;
    private Calendar calendar;
    private ArrayList<String> one_journey;
    private int[] selected_index = {-1};
    private String reminder_gap = "once_a_day";
    private LayoutInflater inflate;
    private String[] casual_cat_names = new String[]{"Clothes", "Electronics", "Cosmetics", "Money", "Bags", "Documents"};
    private ArrayList<String> casual_category = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        getWindow().setStatusBarColor(getResources().getColor(R.color.trans));
        sharedPreferences = getSharedPreferences("heckBagB170", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        isMute = sharedPreferences.getBoolean("isMute", false);
        soundMute = sharedPreferences.getBoolean("soundMute", false);
        lang = sharedPreferences.getString("lang", "");
        one_edit_journey_id = sharedPreferences.getInt("one_edit_journey_id", -1);
        is_history_view = sharedPreferences.getBoolean("is_history_view", false);

        setContentView(R.layout.activity_edit_journey);
        dataManager = new DataManager(this);
        calendar = Calendar.getInstance();

        casual_category.add("cat_0");
        casual_category.add("cat_1");
        casual_category.add("cat_2");
        casual_category.add("cat_3");
        casual_category.add("cat_4");
        casual_category.add("cat_5");

        inflate = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);

        layout_vertical_category = findViewById(R.id.layout_vertical_category);
        add_category = findViewById(R.id.add_category);
        back = findViewById(R.id.back);
        check_bag = findViewById(R.id.check_bag);
        check_mode = findViewById(R.id.check_mode);
        reminder_time = findViewById(R.id.reminder_time);
        reminder_date = findViewById(R.id.reminder_date);
        return_trip_mode = findViewById(R.id.return_trip_mode);
        add_reminder = findViewById(R.id.add_reminder);
        finish_journey = findViewById(R.id.finish_journey);
        delete_journey = findViewById(R.id.delete_journey);
        title = findViewById(R.id.title);
        departure_time = findViewById(R.id.departure_time);
        destination_time = findViewById(R.id.destimation_time);
        departure = findViewById(R.id.departure);
        destination = findViewById(R.id.destination);
        ride_time = findViewById(R.id.ride_time);
        edit_journey = findViewById(R.id.edit_journey);

        once_a_day = findViewById(R.id.once_a_day);
        once_a_week = findViewById(R.id.once_a_week);
        once_a_month = findViewById(R.id.once_a_month);

        edit_journey.setVisibility(GONE);

        one_journey = dataManager.getJourneyItemsByItemID(one_edit_journey_id);
        title.setText(one_journey.get(1));
        departure.setText(one_journey.get(2));
        departure_time.setText(Player.get_string_datetime_from_timestamp(one_journey.get(3))[1]);
        destination.setText(one_journey.get(4));
        destination_time.setText(Player.get_string_datetime_from_timestamp(one_journey.get(5))[1]);
        ride_time.setText(Player.get_ride_time(one_journey.get(5), one_journey.get(3)));

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                finish();
            }
        });

        reminder_time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                load_reminder_time_picker(reminder_time.getText().toString());
            }
        });
        reminder_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                String[] remi_date_time = new String[]{reminder_date.getText().toString(), reminder_time.getText().toString()};
                String remi_timestamp = Player.get_string_timestamp_from_datetime(remi_date_time);

                calendar.setTimeInMillis(Long.parseLong(remi_timestamp));
                load_reminder_date_picker();
            }
        });

        ArrayList<String> one_reminder = dataManager.getReminderItemsByItemID(one_edit_journey_id);
        String[] date_time;
        if (one_reminder.isEmpty()) {
            date_time = Player.get_string_datetime_from_timestamp(System.currentTimeMillis() + "");
            add_reminder.setText(getResources().getString(R.string.add));
        } else {
            date_time = Player.get_string_datetime_from_timestamp(one_reminder.get(2));
            add_reminder.setText(getResources().getString(R.string.update));
            reminder_gap = one_reminder.get(3);

            update_reminder_type();
        }

        reminder_date.setText(date_time[0]);
        reminder_time.setText(date_time[1]);

        add_category.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                intent = new Intent(EditJourneyActivity.this, CategoriesThingsActivity.class);
                startActivity(intent);
                finish();
            }
        });

        add_reminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                String[] remi_date_time = new String[]{reminder_date.getText().toString(), reminder_time.getText().toString()};
                String remi_timestamp = Player.get_string_timestamp_from_datetime(remi_date_time);

                if (Player.get_ride_time(remi_timestamp, System.currentTimeMillis() + "") != null) {
                    if (Player.get_ride_time(one_journey.get(3), remi_timestamp) != null) {
                        String dd = Player.get_string_datetime_from_timestamp(System.currentTimeMillis() + "")[0];
                        String tt = Player.get_string_datetime_from_timestamp(remi_timestamp)[1];
                        String last_remi_timestamp = Player.get_string_timestamp_from_datetime(new String[]{dd, tt});

                        if (one_reminder.isEmpty()) {
                            dataManager.addItemReminder(one_edit_journey_id, remi_timestamp, reminder_gap, last_remi_timestamp);
                            Toast.makeText(EditJourneyActivity.this, "Reminder created successfully!", Toast.LENGTH_SHORT).show();
                        } else {
                            ContentValues values = new ContentValues();
                            values.put(DatabaseHelper.JOURNEY_ID, one_edit_journey_id);
                            values.put(DatabaseHelper.REMINDER_TIMESTAMP, remi_timestamp);
                            values.put(DatabaseHelper.REMINDER_GAP, reminder_gap);
                            values.put(DatabaseHelper.LAST_REMINDER_TIMESTAMP, last_remi_timestamp);

                            dataManager.updateItemReminder(one_edit_journey_id, values);

                            Toast.makeText(EditJourneyActivity.this, "Reminder updated successfully!", Toast.LENGTH_SHORT).show();
                        }

                        intent = new Intent(EditJourneyActivity.this, EditJourneyActivity.class);
                        startActivity(intent);
                        overridePendingTransition(0, 0);
                        finish();

                        update_all_notification();
                    } else
                        Toast.makeText(EditJourneyActivity.this, "Reminder time should be in the past of departure time!", Toast.LENGTH_SHORT).show();
                } else
                    Toast.makeText(EditJourneyActivity.this, "Reminder time is far behind current time!", Toast.LENGTH_SHORT).show();
            }
        });

        check_mode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

            }
        });

        return_trip_mode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);


            }
        });

        check_bag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                intent = new Intent(EditJourneyActivity.this, CheckBagActivity.class);
                startActivity(intent);
                finish();

            }
        });

        once_a_day.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                reminder_gap = "once_a_day";
                update_reminder_type();
            }
        });

        once_a_week.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                reminder_gap = "once_a_week";
                update_reminder_type();
            }
        });

        once_a_month.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                reminder_gap = "once_a_month";
                update_reminder_type();
            }
        });

        finish_journey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                dataManager.execute("UPDATE " + DatabaseHelper.TABLE_MAIN + " SET " + DatabaseHelper.STATUS + "='" + DatabaseHelper.DONE + "' WHERE " + DatabaseHelper.COLUMN_ID + "=" + one_edit_journey_id);

                // delete reminder
                dataManager.execute("DELETE FROM " + DatabaseHelper.TABLE_REMINDER + " WHERE " + DatabaseHelper.JOURNEY_ID + "=" + one_edit_journey_id);

                intent = new Intent(EditJourneyActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        delete_journey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                // while delete row, delete related image also
                dataManager.execute("DELETE FROM " + DatabaseHelper.TABLE_MAIN + " WHERE " + DatabaseHelper.COLUMN_ID + "=" + one_edit_journey_id);
                dataManager.execute("DELETE FROM " + DatabaseHelper.TABLE_REMINDER + " WHERE " + DatabaseHelper.JOURNEY_ID + "=" + one_edit_journey_id);
                dataManager.execute("DELETE FROM " + DatabaseHelper.TABLE_THING + " WHERE " + DatabaseHelper.JOURNEY_ID + "=" + one_edit_journey_id);

                intent = new Intent(EditJourneyActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        load_category_belong_journey();

        if (is_history_view) {
            add_reminder.setVisibility(GONE);
            finish_journey.setVisibility(GONE);
            delete_journey.setVisibility(GONE);

            reminder_time.setEnabled(false);
            reminder_date.setEnabled(false);
        }
    }

    private void update_all_notification() {
        TaskScheduler.cancelAllNotifications(EditJourneyActivity.this);
        String query = "Select * from " + DatabaseHelper.TABLE_REMINDER;
        ArrayList<ArrayList<String>> all_reminder = dataManager.getAllIReminder(query);

        for (int i = 0; i < all_reminder.size(); i++) {
            int journey_id = Integer.parseInt(all_reminder.get(i).get(1));
            ArrayList<String> one_journey = dataManager.getJourneyItemsByItemID(journey_id);

            long remi_timestamp = Long.parseLong(all_reminder.get(i).get(2));
            long cur_timestamp = System.currentTimeMillis();
            long last_reminder_timestamp = Long.parseLong(all_reminder.get(i).get(4));

            String date = Player.get_datetime(last_reminder_timestamp + "")[0];
            String time = Player.get_datetime(last_reminder_timestamp + "")[1];

            save_task_to_notification(journey_id, date, time, 0);
        }
    }

    private void save_task_to_notification(long id_value, String date, String time, int duration) {
        Calendar taskDateTime = getTaskDateTime(date, time);
        TaskScheduler.scheduleTaskNotification(EditJourneyActivity.this, id_value, taskDateTime, duration);
    }

    public static Calendar getTaskDateTime(String date, String time) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.getDefault());
        Calendar calendar = Calendar.getInstance();

        try {
            String combined = date + " " + time;
            calendar.setTime(dateFormat.parse(combined));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return calendar;
    }

    private void load_category_belong_journey() {
        layout_vertical_category.removeAllViews();
        String query = "SELECT * FROM " + DatabaseHelper.TABLE_THING + " WHERE " + DatabaseHelper.JOURNEY_ID + "=" + one_edit_journey_id + " GROUP BY " + DatabaseHelper.CATEGORY;
        ArrayList<ArrayList<String>> all_things = dataManager.getAllItemsThings(query);

        int counter = 0;
        int s = all_things.size();
        int col = 3;
        int row = (int) Math.ceil((double) s / col);
        if (s != 0 && row == 0)
            row = 1;
        for (int i = 0; i < row; i++) {
            View horizontal = inflate.inflate(R.layout.horizontal_category, null);
            LinearLayout layout_horizontal = horizontal.findViewById(R.id.layout_horizontal);
            layout_horizontal.removeAllViews();

            for (int j = 0; j < col; j++) {
                if (counter >= s) break;

                View mini_category = inflate.inflate(R.layout.mini_category_card, null);
                ImageView category = mini_category.findViewById(R.id.category_img);
                TextView name = mini_category.findViewById(R.id.category_name);

                String cat_name = all_things.get(counter).get(6);
                String cat_sor = all_things.get(counter).get(7);

                if (cat_sor.equals(DatabaseHelper.CASUAL))
                    cat_name = casual_cat_names[casual_category.indexOf(cat_name)];

                name.setText(cat_name);

                if (cat_sor.equals(DatabaseHelper.CASUAL)) {
                    int f = getResources().getIdentifier(all_things.get(counter).get(6), "drawable", getPackageName());
                    category.setImageBitmap(BitmapFactory.decodeResource(getResources(), f));
                } else {
                    Bitmap bitmap = loadImageFromInternalStorage(cat_name);
                    if (bitmap != null)
                        category.setImageBitmap(bitmap);
                }

                layout_horizontal.addView(mini_category);
                counter++;
            }

            layout_vertical_category.addView(horizontal);
        }

    }

    private void update_reminder_type() {
        once_a_day.setImageResource(R.drawable.not_checked);
        once_a_week.setImageResource(R.drawable.not_checked);
        once_a_month.setImageResource(R.drawable.not_checked);

        if (reminder_gap.equals("once_a_day"))
            once_a_day.setImageResource(R.drawable.checked);
        else if (reminder_gap.equals("once_a_week"))
            once_a_week.setImageResource(R.drawable.checked);
        else
            once_a_month.setImageResource(R.drawable.checked);
    }

    private void load_reminder_time_picker(String time) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = LayoutInflater.from(this);
        View view = inflater.inflate(R.layout.custom_time_picker, null);
        builder.setView(view);

        TextView hour = view.findViewById(R.id.hour);
        TextView minute = view.findViewById(R.id.minute);
        TextView type = view.findViewById(R.id.type);

        ImageView hour_up = view.findViewById(R.id.hour_up);
        ImageView hour_down = view.findViewById(R.id.hour_down);
        ImageView minute_up = view.findViewById(R.id.minute_up);
        ImageView minute_down = view.findViewById(R.id.minute_down);

        builder.setCancelable(false);
        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alertDialog.show();

        String[] parts = time.split(" ");
        String timePart = parts[0];
        String tt = parts[1];

        String[] timeParts = timePart.split(":");
        final int[] hh = {Integer.parseInt(timeParts[0])};
        final int[] mm = {Integer.parseInt(timeParts[1])};
        final boolean[] is_am = {tt.equals("AM")};

        final String[][] hm_value = {Player.update_time(hour, minute, type, hh[0], mm[0], is_am[0])};
        hh[0] = Integer.parseInt(hm_value[0][0]);
        mm[0] = Integer.parseInt(hm_value[0][1]);

        hour_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                hh[0]++;
                hm_value[0] = Player.update_time(hour, minute, type, hh[0], mm[0], is_am[0]);
                hh[0] = Integer.parseInt(hm_value[0][0]);
                mm[0] = Integer.parseInt(hm_value[0][1]);
            }
        });
        hour_down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                hh[0]--;
                hm_value[0] = Player.update_time(hour, minute, type, hh[0], mm[0], is_am[0]);
                hh[0] = Integer.parseInt(hm_value[0][0]);
                mm[0] = Integer.parseInt(hm_value[0][1]);
            }
        });

        minute_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                mm[0]++;
                hm_value[0] = Player.update_time(hour, minute, type, hh[0], mm[0], is_am[0]);
                hh[0] = Integer.parseInt(hm_value[0][0]);
                mm[0] = Integer.parseInt(hm_value[0][1]);
            }
        });
        minute_down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                mm[0]--;
                hm_value[0] = Player.update_time(hour, minute, type, hh[0], mm[0], is_am[0]);
                hh[0] = Integer.parseInt(hm_value[0][0]);
                mm[0] = Integer.parseInt(hm_value[0][1]);
            }
        });

        type.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);
                is_am[0] = !is_am[0];

                hm_value[0] = Player.update_time(hour, minute, type, hh[0], mm[0], is_am[0]);
                hh[0] = Integer.parseInt(hm_value[0][0]);
                mm[0] = Integer.parseInt(hm_value[0][1]);
            }
        });

        hour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                reminder_time.setText(hm_value[0][2]);
                alertDialog.dismiss();
            }
        });

        minute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                reminder_time.setText(hm_value[0][2]);
                alertDialog.dismiss();
            }
        });
    }

    private void load_reminder_date_picker() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = LayoutInflater.from(this);
        View view = inflater.inflate(R.layout.custom_date_picker, null);
        builder.setView(view);

        TextView txtMonthYear = view.findViewById(R.id.txt_month_year);
        GridLayout calendarGrid = view.findViewById(R.id.calendar_grid);
        ImageView btnPrev = view.findViewById(R.id.btn_prev);
        ImageView btnNext = view.findViewById(R.id.btn_next);

        builder.setCancelable(false);
        AlertDialog alertDialog = builder.create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        alertDialog.show();
        alertDialog.setCancelable(true);

        btnPrev.setOnClickListener(v -> {
            calendar.add(Calendar.MONTH, -1);
            update_date_remi(txtMonthYear, calendarGrid, alertDialog);
        });

        btnNext.setOnClickListener(v -> {
            calendar.add(Calendar.MONTH, 1);
            update_date_remi(txtMonthYear, calendarGrid, alertDialog);
        });

        update_date_remi(txtMonthYear, calendarGrid, alertDialog);
    }

    private void update_date_remi(TextView txtMonthYear, GridLayout calendarGrid, AlertDialog alertDialog) {
        calendarGrid.removeAllViews();

        SimpleDateFormat sdf = new SimpleDateFormat("MMMM yyyy", Locale.getDefault());
        txtMonthYear.setText(sdf.format(calendar.getTime()));

        Calendar displayCal = (Calendar) calendar.clone();
        displayCal.set(Calendar.DAY_OF_MONTH, 1);

        int currentMonth = displayCal.get(Calendar.MONTH);
        int firstDayOfWeek = displayCal.get(Calendar.DAY_OF_WEEK) - 1;
        displayCal.add(Calendar.DAY_OF_MONTH, -firstDayOfWeek);

        String[] days = {"S", "M", "T", "W", "T", "F", "S"};
        for (String day : days) {
            TextView tv = new TextView(this);
            tv.setText(day);
            calendarGrid.addView(tv);
            tv.setTextColor(getResources().getColor(R.color.title_text));
            tv.setTextSize(21);
            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            tv.setWidth(100);
            tv.setHeight(100);
        }

        int totalCells = 0;
        int counter = 0;
        for (int week = 0; week < 6; week++) {
            int nonCurrentMonthCount = 0;
            View[] rowViews = new View[7];

            for (int dayOfWeek = 0; dayOfWeek < 7; dayOfWeek++) {
                int drawMonth = displayCal.get(Calendar.MONTH);

                TextView dayView = new TextView(this);
                dayView.setText(String.valueOf(displayCal.get(Calendar.DAY_OF_MONTH)));
                dayView.setPadding(20, 20, 20, 20);
                dayView.setTextColor(getResources().getColor(R.color.title_text));
                dayView.setTextSize(21);
                dayView.setWidth(100);
                dayView.setHeight(100);
                dayView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

                if (selected_index[0] == counter)
                    dayView.setBackgroundResource(R.drawable.bg_btn_yellow);
                else
                    dayView.setBackgroundResource(R.color.trans);

                if (drawMonth != currentMonth) {
                    dayView.setAlpha(0.3f);
                    dayView.setEnabled(false);
                    nonCurrentMonthCount++;
                } else {
                    Calendar selected = (Calendar) displayCal.clone();
                    int finalCounter = counter;
                    dayView.setOnClickListener(v -> {
                        long timestamp = selected.getTimeInMillis();
                        String[] date_time = Player.get_string_datetime_from_timestamp(timestamp + "");

                        reminder_date.setText(date_time[0]);

                        if (selected_index[0] == finalCounter)
                            alertDialog.dismiss();
                        else {
                            selected_index[0] = finalCounter;
                            update_date_remi(txtMonthYear, calendarGrid, alertDialog);
                        }

                    });
                }

                rowViews[dayOfWeek] = dayView;
                displayCal.add(Calendar.DAY_OF_MONTH, 1);

                counter++;
            }

            if (nonCurrentMonthCount < 7) {
                for (View view : rowViews) {
                    calendarGrid.addView(view);
                    totalCells++;
                }
            }
        }
    }

    public Bitmap loadImageFromInternalStorage(String file_name) {
        File directory = new File(getFilesDir(), "saved_images");
        if (!directory.exists()) {
            directory.mkdir();
        }

        File file = new File(directory, file_name + ".jpg");
        String path = file.getAbsolutePath();
        Bitmap bitmap = null;
        try {
            file = new File(path);
            if (file.exists()) {
                bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return bitmap;
    }

    @Override
    protected void onPause() {
        super.onPause();
//        if (!isMute)
//            Player.all_screens.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
//        isMute = sharedPreferences.getBoolean("isMute", false);
//        if (!isMute)
//            Player.all_screens.start();
    }

    @Override
    public void onBackPressed() {
        return;
    }
}