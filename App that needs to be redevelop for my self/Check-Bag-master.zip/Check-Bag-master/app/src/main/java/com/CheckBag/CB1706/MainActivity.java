package com.CheckBag.CB1706;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationManagerCompat;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private Button reminders, history;

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private ImageView create;
    private LinearLayout layout_vertical;
    private boolean isMute, soundMute;
    private String lang;
    private LayoutInflater inflate;
    private Intent intent;
    private DataManager dataManager;
    private ArrayList<ArrayList<String>> all_journey = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        getWindow().setStatusBarColor(getResources().getColor(R.color.trans));
        sharedPreferences = getSharedPreferences("heckBagB170", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        isMute = sharedPreferences.getBoolean("isMute", false);
        soundMute = sharedPreferences.getBoolean("soundMute", false);
        lang = sharedPreferences.getString("lang", "");

        setContentView(R.layout.activity_main);
        dataManager = new DataManager(this);

        create = findViewById(R.id.create);
        layout_vertical = findViewById(R.id.layout_vertical);
        inflate = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        reminders = findViewById(R.id.reminders);
        history = findViewById(R.id.history);

        request_notification_permission(this);

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                editor.putBoolean("is_history_view", false);
                editor.putInt("one_edit_journey_id", -1);
                editor.apply();

                intent = new Intent(MainActivity.this, CreateJourneyActivity.class);
                startActivity(intent);
                finish();
            }
        });

        reminders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                intent = new Intent(MainActivity.this, RemindersActivity.class);
                startActivity(intent);
            }
        });

        history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                intent = new Intent(MainActivity.this, HistoryActivity.class);
                startActivity(intent);
            }
        });
    }

    public boolean check_notification_permission(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            return NotificationManagerCompat.from(context).areNotificationsEnabled();
        else
            return true;
    }

    public void request_notification_permission(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!check_notification_permission(activity)) {
                new androidx.appcompat.app.AlertDialog.Builder(activity)
                        .setMessage("The app needs notification permission to send reminders.")
                        .setPositiveButton("Grant", (dialog, which) -> {
                            Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                            intent.putExtra(Settings.EXTRA_APP_PACKAGE, activity.getPackageName());
                            activity.startActivity(intent);
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            }
        }
    }

    private void load_journey() {
        String query = "Select * from " + DatabaseHelper.TABLE_MAIN + " where " + DatabaseHelper.STATUS + "='" + DatabaseHelper.PENDING + "'";
        all_journey = dataManager.getAllItems(query);
        layout_vertical.removeAllViews();

        for (int i = 0; i < all_journey.size(); i++) {
            View journeys_card = inflate.inflate(R.layout.journeys_card, null);
            LinearLayout layout_card = journeys_card.findViewById(R.id.layout_card);
            TextView title = journeys_card.findViewById(R.id.title);
            TextView departure_time = journeys_card.findViewById(R.id.departure_time);
            TextView destination_time = journeys_card.findViewById(R.id.destimation_time);
            TextView departure = journeys_card.findViewById(R.id.departure);
            TextView destination = journeys_card.findViewById(R.id.destination);
            TextView ride_time = journeys_card.findViewById(R.id.ride_time);
            ImageView edit_journey = journeys_card.findViewById(R.id.edit_journey);

            title.setText(all_journey.get(i).get(1));
            departure.setText(all_journey.get(i).get(2));
            departure_time.setText(Player.get_string_datetime_from_timestamp(all_journey.get(i).get(3))[1]);
            destination.setText(all_journey.get(i).get(4));
            destination_time.setText(Player.get_string_datetime_from_timestamp(all_journey.get(i).get(5))[1]);
            ride_time.setText(Player.get_ride_time(all_journey.get(i).get(5), all_journey.get(i).get(3)));

            int finalI = i;

            layout_card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Player.button(soundMute);
                    editor.putInt("one_edit_journey_id", Integer.parseInt(all_journey.get(finalI).get(0)));
                    editor.apply();

                    editor.putBoolean("is_history_view", false);
                    editor.apply();

                    intent = new Intent(MainActivity.this, EditJourneyActivity.class);
                    startActivity(intent);
                }
            });

            edit_journey.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Player.button(soundMute);

                    editor.putBoolean("is_history_view", false);
                    editor.putInt("one_edit_journey_id", Integer.parseInt(all_journey.get(finalI).get(0)));
                    editor.apply();

                    intent = new Intent(MainActivity.this, CreateJourneyActivity.class);
                    startActivity(intent);
                    finish();
                }
            });

            layout_vertical.addView(journeys_card);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
//        if (!isMute)
//            Player.all_screens.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();

        load_journey();
//        isMute = sharedPreferences.getBoolean("isMute", false);
//        if (!isMute)
//            Player.all_screens.start();
    }

    @Override
    public void onBackPressed() {
        finishAffinity();
    }

}