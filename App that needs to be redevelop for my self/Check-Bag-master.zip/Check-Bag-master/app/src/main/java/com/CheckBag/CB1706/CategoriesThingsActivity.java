package com.CheckBag.CB1706;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class CategoriesThingsActivity extends AppCompatActivity {
    private ImageView create_add, back;
    private Button categories, things;
    private EditText search_categories;
    private LinearLayout layout_vertical_casual_categories, layout_vertical_custom_categories;
    private LinearLayout layout_categories, layout_things;

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private boolean isMute, soundMute;
    private String lang;
    private Intent intent;
    private LayoutInflater inflate;
    private boolean active_is_categories = true;
    private String[] casual_cat_names = new String[]{"Clothes", "Electronics", "Cosmetics", "Money", "Bags", "Documents"};
    private ArrayList<String> casual_category = new ArrayList<>();
    private ArrayList<String> custom_category = new ArrayList<>();
    private String custom_category_str;
    private int one_edit_journey_id;
    private boolean is_history_view;
    private DataManager dataManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        getWindow().setStatusBarColor(getResources().getColor(R.color.trans));
        sharedPreferences = getSharedPreferences("heckBagB170", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        isMute = sharedPreferences.getBoolean("isMute", false);
        soundMute = sharedPreferences.getBoolean("soundMute", false);
        lang = sharedPreferences.getString("lang", "");
        custom_category_str = sharedPreferences.getString("custom_category", "");
        one_edit_journey_id = sharedPreferences.getInt("one_edit_journey_id", -1);
        is_history_view = sharedPreferences.getBoolean("is_history_view", false);

        setContentView(R.layout.activity_categories_things);
        dataManager = new DataManager(this);

        inflate = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);

        casual_category.add("cat_0");
        casual_category.add("cat_1");
        casual_category.add("cat_2");
        casual_category.add("cat_3");
        casual_category.add("cat_4");
        casual_category.add("cat_5");
        if (!custom_category_str.isEmpty()) {
            String[] all_cat = custom_category_str.split(Player.category_separator);
            Collections.addAll(custom_category, all_cat);
        }

        back = findViewById(R.id.back);
        create_add = findViewById(R.id.create_add);
        categories = findViewById(R.id.category_img);
        things = findViewById(R.id.things);
        search_categories = findViewById(R.id.search_categories);
        layout_vertical_casual_categories = findViewById(R.id.layout_vertical_casual_categories);
        layout_vertical_custom_categories = findViewById(R.id.layout_vertical_custom_categories);
        layout_categories = findViewById(R.id.layout_categories);
        layout_things = findViewById(R.id.layout_things);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                intent = new Intent(CategoriesThingsActivity.this, EditJourneyActivity.class);
                startActivity(intent);
                finish();
            }
        });

        categories.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                active_is_categories = true;
                check_active_tab();
            }
        });

        things.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                active_is_categories = false;
                check_active_tab();
            }
        });

        create_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                if (active_is_categories)
                    intent = new Intent(CategoriesThingsActivity.this, CreateCategoryActivity.class);
                else
                    intent = new Intent(CategoriesThingsActivity.this, AddThingsActivity.class);

                editor.putInt("one_edit_thing_id", -1);
                editor.apply();

                startActivity(intent);
                overridePendingTransition(0, 0);
                finish();
            }
        });

        search_categories.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                load_category_data();
            }
        });

        check_active_tab();

        if (is_history_view)
            create_add.setVisibility(GONE);
    }

    private void check_active_tab() {
        categories.setBackgroundResource(R.drawable.bg_btn_inactive);
        things.setBackgroundResource(R.drawable.bg_btn_inactive);

        if (active_is_categories) {
            categories.setBackgroundResource(R.drawable.bg_btn_yellow);
            layout_categories.setVisibility(VISIBLE);
            layout_things.setVisibility(GONE);
            create_add.setImageResource(R.drawable.create);
            load_category_data();
        } else {
            things.setBackgroundResource(R.drawable.bg_btn_yellow);
            layout_categories.setVisibility(GONE);
            layout_things.setVisibility(VISIBLE);
            create_add.setImageResource(R.drawable.add_text);
            load_things_data();
        }
    }

    private void load_category_data() {
        String search_value = search_categories.getText().toString();

        layout_vertical_casual_categories.removeAllViews();
        int counter = 0;
        int search_counter = 0;
        int one_row = 0;

        View horizontal = inflate.inflate(R.layout.horizontal_category, null);
        LinearLayout layout_horizontal = horizontal.findViewById(R.id.layout_horizontal);
        layout_horizontal.removeAllViews();
        for (int i = 0; i < casual_category.size(); i++) {
            if (one_row == 3) {
                horizontal = inflate.inflate(R.layout.horizontal_category, null);
                layout_horizontal = horizontal.findViewById(R.id.layout_horizontal);
                layout_horizontal.removeAllViews();
                one_row = 0;
            }

            if (counter >= casual_category.size()) break;

            View mini_category = inflate.inflate(R.layout.mini_category_card, null);
            ImageView category = mini_category.findViewById(R.id.category_img);
            TextView name = mini_category.findViewById(R.id.category_name);

            int f = getResources().getIdentifier(casual_category.get(counter), "drawable", getPackageName());
            category.setImageBitmap(BitmapFactory.decodeResource(getResources(), f));

            if (search_value.isEmpty()) {
                name.setText(casual_cat_names[counter]);
                layout_horizontal.addView(mini_category);
                one_row++;
            } else if (casual_cat_names[search_counter].toLowerCase().contains(search_value.toLowerCase())) {
                name.setText(casual_cat_names[search_counter]);
                layout_horizontal.addView(mini_category);
                one_row++;
            }
            counter++;
            search_counter++;

            if (one_row == 3 || casual_category.size() == counter)
                layout_vertical_casual_categories.addView(horizontal);
        }

        layout_vertical_custom_categories.removeAllViews();
        counter = 0;
        search_counter = 0;
        one_row = 0;

        horizontal = inflate.inflate(R.layout.horizontal_category, null);
        layout_horizontal = horizontal.findViewById(R.id.layout_horizontal);
        layout_horizontal.removeAllViews();
        for (int i = 0; i < custom_category.size(); i++) {
            if (one_row == 3) {
                horizontal = inflate.inflate(R.layout.horizontal_category, null);
                layout_horizontal = horizontal.findViewById(R.id.layout_horizontal);
                layout_horizontal.removeAllViews();
                one_row = 0;
            }

            if (counter >= custom_category.size()) break;

            View mini_category = inflate.inflate(R.layout.mini_category_card, null);
            ImageView category = mini_category.findViewById(R.id.category_img);
            TextView name = mini_category.findViewById(R.id.category_name);

            Bitmap bitmap = loadImageFromInternalStorage(custom_category.get(counter));
            if (bitmap != null)
                category.setImageBitmap(bitmap);

            if (search_value.isEmpty()) {
                name.setText(custom_category.get(counter));
                layout_horizontal.addView(mini_category);
                one_row++;
            } else if (custom_category.get(search_counter).toLowerCase().contains(search_value.toLowerCase())) {
                name.setText(custom_category.get(search_counter));
                layout_horizontal.addView(mini_category);
                one_row++;
            }
            counter++;
            search_counter++;

            if (one_row == 3 || custom_category.size() == counter)
                layout_vertical_custom_categories.addView(horizontal);
        }
    }

    private void load_things_data() {
        layout_things.removeAllViews();
        String query = "SELECT * FROM " + DatabaseHelper.TABLE_THING + " WHERE " + DatabaseHelper.JOURNEY_ID + "=" + one_edit_journey_id;
        ArrayList<ArrayList<String>> all_things = dataManager.getAllItemsThings(query);

        for (int i = 0; i < all_things.size(); i++) {
            View things_card = inflate.inflate(R.layout.things_card, null);
            LinearLayout layout_card = things_card.findViewById(R.id.layout_card);
            LinearLayout layout_edit_mode = things_card.findViewById(R.id.layout_edit_mode);

            TextView category = things_card.findViewById(R.id.category);
            TextView title = things_card.findViewById(R.id.title);
            TextView comment = things_card.findViewById(R.id.comments);
            ImageView things_image = things_card.findViewById(R.id.thing_image);

            ImageView status = things_card.findViewById(R.id.status);
            ImageView edit = things_card.findViewById(R.id.edit);
            ImageView delete = things_card.findViewById(R.id.delete);

            layout_edit_mode.setVisibility(GONE);

            String cat_name = all_things.get(i).get(6);
            String cat_sor = all_things.get(i).get(7);
            if (cat_sor.equals(DatabaseHelper.CASUAL))
                cat_name = casual_cat_names[casual_category.indexOf(cat_name)];

            category.setText(cat_name + " -> " + all_things.get(i).get(5));
            title.setText(all_things.get(i).get(2));
            comment.setText(all_things.get(i).get(3));
            if (!all_things.get(i).get(4).isEmpty()) {
                Bitmap bitmap = loadImageFromInternalStorage(all_things.get(i).get(4));
                if (bitmap != null)
                    things_image.setImageBitmap(bitmap);
            }
            layout_things.addView(things_card);
        }
    }

    public Bitmap loadImageFromInternalStorage(String file_name) {
        File directory = new File(getFilesDir(), "saved_images");
        if (!directory.exists()) {
            directory.mkdir();
        }

        File file = new File(directory, file_name + ".jpg");
        String path = file.getAbsolutePath();
        Bitmap bitmap = null;
        try {
            file = new File(path);
            if (file.exists()) {
                bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return bitmap;
    }

    @Override
    protected void onPause() {
        super.onPause();
//        if (!isMute)
//            Player.all_screens.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
//        isMute = sharedPreferences.getBoolean("isMute", false);
//        if (!isMute)
//            Player.all_screens.start();
    }

    @Override
    public void onBackPressed() {
        return;
    }
}