package com.CheckBag.CB1706;

import static android.view.View.GONE;
import static android.view.View.INVISIBLE;
import static android.view.View.VISIBLE;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class CheckBagActivity extends AppCompatActivity {
    private ImageView back;
    private Button things_check, return_journey;
    private EditText search_things;
    private LinearLayout layout_things;

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private boolean isMute, soundMute;
    private String lang;
    private Intent intent;
    private LayoutInflater inflate;
    private boolean active_is_check = true;
    private int one_edit_journey_id;
    private boolean is_history_view;
    private DataManager dataManager;
    private String[] casual_cat_names = new String[]{"Clothes", "Electronics", "Cosmetics", "Money", "Bags", "Documents"};
    private ArrayList<String> casual_category = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        getWindow().setStatusBarColor(getResources().getColor(R.color.trans));
        sharedPreferences = getSharedPreferences("heckBagB170", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        isMute = sharedPreferences.getBoolean("isMute", false);
        soundMute = sharedPreferences.getBoolean("soundMute", false);
        lang = sharedPreferences.getString("lang", "");
        one_edit_journey_id = sharedPreferences.getInt("one_edit_journey_id", -1);
        is_history_view = sharedPreferences.getBoolean("is_history_view", false);

        setContentView(R.layout.activity_check_bag);
        dataManager = new DataManager(this);

        casual_category.add("cat_0");
        casual_category.add("cat_1");
        casual_category.add("cat_2");
        casual_category.add("cat_3");
        casual_category.add("cat_4");
        casual_category.add("cat_5");

        inflate = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);

        back = findViewById(R.id.back);
        things_check = findViewById(R.id.things_check);
        return_journey = findViewById(R.id.return_journey);
        search_things = findViewById(R.id.search_things);
        layout_things = findViewById(R.id.layout_things);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                intent = new Intent(CheckBagActivity.this, EditJourneyActivity.class);
                startActivity(intent);
                finish();
            }
        });

        things_check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                active_is_check = true;
                check_active_tab();
            }
        });

        return_journey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Player.button(soundMute);

                active_is_check = false;
                check_active_tab();
            }
        });

        search_things.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                load_all_things();
            }
        });

        check_active_tab();
    }

    private void check_active_tab() {
        things_check.setBackgroundResource(R.drawable.bg_btn_inactive);
        return_journey.setBackgroundResource(R.drawable.bg_btn_inactive);

        if (active_is_check)
            things_check.setBackgroundResource(R.drawable.bg_btn_yellow);
         else
            return_journey.setBackgroundResource(R.drawable.bg_btn_yellow);

        load_all_things();
    }

    private void load_all_things() {
        layout_things.removeAllViews();
        String query = "SELECT * FROM " + DatabaseHelper.TABLE_THING + " WHERE " + DatabaseHelper.JOURNEY_ID + "=" + one_edit_journey_id;
        if (!active_is_check)
            query = "SELECT * FROM " + DatabaseHelper.TABLE_THING + " WHERE " + DatabaseHelper.JOURNEY_ID + "=" + one_edit_journey_id +
                    " AND " + DatabaseHelper.STATUS +"!='" + DatabaseHelper.PENDING + "'";

        ArrayList<ArrayList<String>> all_things = dataManager.getAllItemsThings(query);

        for (int i = 0; i < all_things.size(); i++) {
            View things_card = inflate.inflate(R.layout.things_card, null);
            LinearLayout layout_card = things_card.findViewById(R.id.layout_card);
            LinearLayout layout_edit_mode = things_card.findViewById(R.id.layout_edit_mode);

            TextView category = things_card.findViewById(R.id.category);
            TextView title = things_card.findViewById(R.id.title);
            TextView comment = things_card.findViewById(R.id.comments);
            ImageView things_image = things_card.findViewById(R.id.thing_image);

            ImageView status = things_card.findViewById(R.id.status);
            ImageView edit = things_card.findViewById(R.id.edit);
            ImageView delete = things_card.findViewById(R.id.delete);

            if (is_history_view)
                layout_edit_mode.setVisibility(GONE);

            String cat_name = all_things.get(i).get(6);
            String cat_sor = all_things.get(i).get(7);
            String st = all_things.get(i).get(8);
            if (cat_sor.equals(DatabaseHelper.CASUAL))
                cat_name = casual_cat_names[casual_category.indexOf(cat_name)];

            category.setText(cat_name + " -> " + all_things.get(i).get(5));
            title.setText(all_things.get(i).get(2));
            comment.setText(all_things.get(i).get(3));
            if (!all_things.get(i).get(4).isEmpty()) {
                Bitmap bitmap = loadImageFromInternalStorage(all_things.get(i).get(4));
                if (bitmap != null)
                    things_image.setImageBitmap(bitmap);
            }

            if (active_is_check) {
                if (st.equals(DatabaseHelper.PENDING)) {
                    status.setImageResource(R.drawable.not_checked);
                    st = DatabaseHelper.CHECKED;
                } else if (st.equals(DatabaseHelper.CHECKED)){
                    status.setImageResource(R.drawable.checked);
                    st = DatabaseHelper.PENDING;
                    edit.setEnabled(false);
                    edit.setAlpha(0.3F);
                }else {
                    status.setImageResource(R.drawable.checked);
                    status.setEnabled(false);
                    status.setAlpha(0.3F);
                    edit.setEnabled(false);
                    edit.setAlpha(0.3F);
                }
            }else {
                edit.setVisibility(INVISIBLE);
                edit.setEnabled(false);
                edit.setAlpha(0.3F);
                if (st.equals(DatabaseHelper.CHECKED)) {
                    status.setImageResource(R.drawable.not_checked);
                    st = DatabaseHelper.RETUNRNED;
                } else {
                    status.setImageResource(R.drawable.checked);
                    st = DatabaseHelper.CHECKED;
                }
            }

            String finalSt = st;
            int one_edit_thing_id = Integer.parseInt(all_things.get(i).get(0));
            status.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Player.button(soundMute);

                    String query = "UPDATE " + DatabaseHelper.TABLE_THING +
                            " SET " + DatabaseHelper.STATUS + "='" + finalSt + "' WHERE " + DatabaseHelper.COLUMN_ID + "=" + one_edit_thing_id;

                    dataManager.execute(query);
                    load_all_things();
                }
            });

            edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Player.button(soundMute);


                    editor.putInt("one_edit_thing_id", one_edit_thing_id);
                    editor.apply();

                    intent = new Intent(CheckBagActivity.this, AddThingsActivity.class);
                    startActivity(intent);
                    finish();
                }
            });

            delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Player.button(soundMute);
                    String query = "DELETE FROM " + DatabaseHelper.TABLE_THING + " WHERE " + DatabaseHelper.COLUMN_ID + "=" + one_edit_thing_id;

                    dataManager.execute(query);
                    load_all_things();
                }
            });


            layout_things.addView(things_card);
        }
    }

    public Bitmap loadImageFromInternalStorage(String file_name) {
        File directory = new File(getFilesDir(), "saved_images");
        if (!directory.exists()) {
            directory.mkdir();
        }

        File file = new File(directory, file_name + ".jpg");
        String path = file.getAbsolutePath();
        Bitmap bitmap = null;
        try {
            file = new File(path);
            if (file.exists()) {
                bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return bitmap;
    }

    @Override
    protected void onPause() {
        super.onPause();
//        if (!isMute)
//            Player.all_screens.pause();
    }

    @Override
    protected void onResume() {
        super.onResume();
//        isMute = sharedPreferences.getBoolean("isMute", false);
//        if (!isMute)
//            Player.all_screens.start();
    }

    @Override
    public void onBackPressed() {
        return;
    }
}